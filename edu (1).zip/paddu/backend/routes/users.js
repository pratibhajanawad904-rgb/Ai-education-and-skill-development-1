/* ========================================
   Users API Routes
   ======================================== */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'mockDB.json');
function loadDB() { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }

// GET /api/users — List all users
router.get('/', (req, res) => {
  const db = loadDB();
  res.json({ success: true, data: db.users });
});

// GET /api/users/:id — Get a single user
router.get('/:id', (req, res) => {
  const db = loadDB();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });
  res.json({ success: true, data: user });
});

// POST /api/users — Create a new user
router.post('/', (req, res) => {
  const { name, email, goal, skillLevel, hoursPerWeek } = req.body;
  if (!name || !email) {
    return res.status(400).json({ success: false, message: 'Name and email are required' });
  }

  const newUser = {
    id: 'u' + Date.now(),
    name,
    email,
    goal: goal || null,
    skillLevel: skillLevel || null,
    hoursPerWeek: hoursPerWeek || null,
    joinedAt: new Date().toISOString()
  };

  // In a real app this would write to a database
  res.status(201).json({ success: true, data: newUser });
});

// PUT /api/users/:id — Update user profile
router.put('/:id', (req, res) => {
  const db = loadDB();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });

  const updated = { ...user, ...req.body };
  res.json({ success: true, data: updated });
});

module.exports = router;
