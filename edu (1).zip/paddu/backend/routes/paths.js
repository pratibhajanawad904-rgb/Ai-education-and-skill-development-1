/* ========================================
   Learning Paths API Routes
   ======================================== */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'mockDB.json');
function loadDB() { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }

// GET /api/paths — List all learning paths
router.get('/', (req, res) => {
  const db = loadDB();
  const paths = Object.entries(db.learningPaths).map(([key, value]) => ({
    id: key,
    ...value
  }));
  res.json({ success: true, data: paths });
});

// GET /api/paths/:id — Get a specific learning path
router.get('/:id', (req, res) => {
  const db = loadDB();
  const pathData = db.learningPaths[req.params.id];
  if (!pathData) return res.status(404).json({ success: false, message: 'Learning path not found' });
  res.json({ success: true, data: { id: req.params.id, ...pathData } });
});

// POST /api/paths/generate — Generate a personalized roadmap
router.post('/generate', (req, res) => {
  const { goal, skillLevel, hoursPerWeek } = req.body;

  if (!goal) {
    return res.status(400).json({ success: false, message: 'Goal is required' });
  }

  const db = loadDB();
  const pathData = db.learningPaths[goal];

  if (!pathData) {
    return res.status(404).json({ success: false, message: 'Invalid goal' });
  }

  let modules = [...pathData.modules];

  // Adjust based on skill level
  if (skillLevel === 'intermediate') {
    modules = modules.slice(2);
  } else if (skillLevel === 'advanced') {
    modules = modules.slice(4);
  }

  res.json({
    success: true,
    data: {
      goal,
      name: pathData.name,
      skillLevel: skillLevel || 'beginner',
      hoursPerWeek: hoursPerWeek || 10,
      totalWeeks: modules.length,
      modules
    }
  });
});

module.exports = router;
