/* ========================================
   Assessments API Routes
   ======================================== */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'mockDB.json');
function loadDB() { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }

// GET /api/assessments/quizzes — Get quiz questions
router.get('/quizzes', (req, res) => {
  const db = loadDB();
  const difficulty = req.query.difficulty || 'easy';
  const quizzes = db.assessments.quizzes.filter(q => q.difficulty === difficulty);
  res.json({ success: true, data: quizzes });
});

// GET /api/assessments/coding — Get coding challenges
router.get('/coding', (req, res) => {
  const db = loadDB();
  res.json({ success: true, data: db.assessments.codingChallenges });
});

// POST /api/assessments/submit — Submit quiz answers and get results
router.post('/submit', (req, res) => {
  const { quizId, answers } = req.body;

  if (!answers || !Array.isArray(answers)) {
    return res.status(400).json({ success: false, message: 'Answers array is required' });
  }

  const db = loadDB();
  const quiz = db.assessments.quizzes.find(q => q.id === quizId);

  if (!quiz) {
    return res.status(404).json({ success: false, message: 'Quiz not found' });
  }

  let correct = 0;
  const results = quiz.questions.map((q, idx) => {
    const isCorrect = answers[idx] === q.correct;
    if (isCorrect) correct++;
    return {
      questionId: q.id,
      selectedAnswer: answers[idx],
      correctAnswer: q.correct,
      isCorrect
    };
  });

  const score = Math.round((correct / quiz.questions.length) * 100);

  // Determine strengths and weaknesses
  const strengths = results.filter(r => r.isCorrect).map(r => 'Correct');
  const weaknesses = results.filter(r => !r.isCorrect).map(r => 'Needs practice');

  // Determine next difficulty
  let nextDifficulty = quiz.difficulty;
  if (score >= 75 && quiz.difficulty === 'easy') nextDifficulty = 'hard';
  if (score < 50 && quiz.difficulty === 'hard') nextDifficulty = 'easy';

  res.json({
    success: true,
    data: {
      score,
      correct,
      total: quiz.questions.length,
      results,
      strengths,
      weaknesses,
      nextDifficulty
    }
  });
});

module.exports = router;
