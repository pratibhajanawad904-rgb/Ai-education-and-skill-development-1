/* ========================================
   Career Recommendations API Routes
   ======================================== */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'mockDB.json');
function loadDB() { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }

// GET /api/careers — Get all career paths
router.get('/', (req, res) => {
  const db = loadDB();
  res.json({ success: true, data: db.careerPaths });
});

// GET /api/careers/recommend — Get personalized recommendations
router.get('/recommend', (req, res) => {
  const goal = req.query.goal || 'webdev';
  const db = loadDB();

  // Filter career paths by goal
  const careers = db.careerPaths.filter(c => c.relatedGoals.includes(goal));

  // Filter courses by goal
  const courses = db.courses.filter(c => c.relatedGoals.includes(goal));

  // Project ideas (hardcoded per goal)
  const projectIdeas = {
    webdev: [
      { title: 'Personal Portfolio Website', description: 'Build a responsive portfolio to showcase your skills and projects.' },
      { title: 'Task Management App', description: 'Create a full-stack to-do app with user authentication and CRUD.' }
    ],
    datascience: [
      { title: 'Exploratory Data Analysis Dashboard', description: 'Analyze and visualize a real-world dataset using Python.' },
      { title: 'Predictive Model for Housing Prices', description: 'Build a regression model to predict house prices.' }
    ],
    aiml: [
      { title: 'Image Classification System', description: 'Build a CNN to classify images from a custom dataset.' },
      { title: 'Chatbot with NLP', description: 'Create an intelligent chatbot using NLP techniques.' }
    ]
  };

  // Internship type
  const internships = {
    webdev: { title: 'Frontend Development Intern', platform: 'LinkedIn, Internshala, AngelList' },
    datascience: { title: 'Data Science Intern', platform: 'LinkedIn, Kaggle Jobs, Internshala' },
    aiml: { title: 'AI/ML Research Intern', platform: 'LinkedIn, Research Labs, Internshala' }
  };

  res.json({
    success: true,
    data: {
      careerPaths: careers.slice(0, 2),
      courses: courses.slice(0, 3),
      projectIdeas: projectIdeas[goal] || projectIdeas['webdev'],
      internship: internships[goal] || internships['webdev']
    }
  });
});

// GET /api/careers/courses — Get all courses
router.get('/courses', (req, res) => {
  const db = loadDB();
  const goal = req.query.goal;

  let courses = db.courses;
  if (goal) {
    courses = courses.filter(c => c.relatedGoals.includes(goal));
  }

  res.json({ success: true, data: courses });
});

module.exports = router;
