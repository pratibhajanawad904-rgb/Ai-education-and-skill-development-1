/* ========================================
   LearnPath — Backend Server
   Express.js + MongoDB Atlas + Gemini AI
   ======================================== */

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');

// Load environment variables
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ──── Middleware ────
app.use(cors());
app.use(express.json());

// Serve frontend static files
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// ──── MongoDB Connection ────
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/learnpath_db';

mongoose.connect(MONGODB_URI)
  .then(() => console.log('  ✅ Connected to MongoDB Atlas'))
  .catch(err => {
    console.warn('  ⚠️  MongoDB connection failed — using mock data fallback');
    console.warn('     Error:', err.message);
  });

// ──── MongoDB Schemas ────
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  goal: { type: String, enum: ['webdev', 'datascience', 'aiml'], default: null },
  skillLevel: { type: String, enum: ['novice', 'beginner', 'intermediate', 'advanced', 'expert'], default: null },
  hoursPerWeek: { type: Number, default: null },
  completedTasks: [String],
  lessonsCompleted: { type: Number, default: 0 },
  totalLessons: { type: Number, default: 40 },
  streak: { type: Number, default: 0 },
  milestones: { type: Number, default: 0 },
  avgScore: { type: Number, default: 0 },
  quizScores: [{
    score: Number,
    difficulty: String,
    date: { type: Date, default: Date.now }
  }],
  codingResults: [{
    score: Number,
    date: { type: Date, default: Date.now }
  }],
  aptitudeScores: [{
    score: Number,
    date: { type: Date, default: Date.now }
  }],
  chatHistory: [{
    role: String,
    message: String,
    timestamp: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now },
  lastActive: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);

// ──── Load Mock Data (fallback) ────
const DB_PATH = path.join(__dirname, 'data', 'mockDB.json');
function loadDB() {
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(raw);
}

// ──── Import Routes ────
const userRoutes = require('./routes/users');
const pathRoutes = require('./routes/paths');
const assessmentRoutes = require('./routes/assessments');
const careerRoutes = require('./routes/careers');

app.use('/api/users', userRoutes);
app.use('/api/paths', pathRoutes);
app.use('/api/assessments', assessmentRoutes);
app.use('/api/careers', careerRoutes);

// ──── Health Check ────
app.get('/api/health', async (req, res) => {
  const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
  res.json({
    status: 'ok',
    message: 'LearnPath API is running',
    database: dbStatus,
    timestamp: new Date().toISOString()
  });
});

// ──── Motivational Message ────
app.get('/api/motivation', (req, res) => {
  const db = loadDB();
  const messages = db.motivationalMessages;
  const random = messages[Math.floor(Math.random() * messages.length)];
  res.json({ message: random });
});

// ──── Gemini AI Chat Endpoint ────
app.post('/api/chat', async (req, res) => {
  const { message, history } = req.body;
  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

  if (!GEMINI_API_KEY) {
    return res.status(500).json({ success: false, message: 'Gemini API key not configured' });
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: {
            parts: [{
              text: `You are "LearnPath AI Mentor", a friendly coding tutor and career mentor. 
              Keep responses concise (2-3 paragraphs). Be encouraging and supportive. 
              Use simple language with practical examples. Focus on programming, web dev, 
              data science, AI/ML, and career guidance.`
            }]
          },
          contents: history || [{ role: 'user', parts: [{ text: message }] }],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 500
          }
        })
      }
    );

    const data = await response.json();
    const aiText = data.candidates?.[0]?.content?.parts?.[0]?.text || 'Sorry, I could not process that. Try again!';

    res.json({ success: true, response: aiText });
  } catch (error) {
    console.error('Gemini API error:', error);
    res.status(500).json({ success: false, message: 'AI service temporarily unavailable' });
  }
});

// ──── MongoDB User Registration ────
app.post('/api/register', async (req, res) => {
  try {
    const { name, email } = req.body;

    if (!name || !email) {
      return res.status(400).json({ success: false, message: 'Name and email are required' });
    }

    // Check if user exists
    let user = await User.findOne({ email });
    if (user) {
      // Update last active
      user.lastActive = new Date();
      await user.save();
      return res.json({ success: true, data: user, isExisting: true });
    }

    // Create new user
    user = new User({ name, email });
    await user.save();
    res.status(201).json({ success: true, data: user, isExisting: false });
  } catch (error) {
    // If MongoDB is not connected, just return success with mock data
    if (mongoose.connection.readyState !== 1) {
      return res.json({ success: true, data: { name: req.body.name, email: req.body.email }, fallback: true });
    }
    console.error('Registration error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// ──── Save Progress to MongoDB ────
app.post('/api/progress', async (req, res) => {
  try {
    const { email, data } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Update progress fields
    if (data.goal) user.goal = data.goal;
    if (data.skillLevel) user.skillLevel = data.skillLevel;
    if (data.hoursPerWeek) user.hoursPerWeek = data.hoursPerWeek;
    if (data.completedTasks) user.completedTasks = data.completedTasks;
    if (data.lessonsCompleted !== undefined) user.lessonsCompleted = data.lessonsCompleted;
    if (data.streak !== undefined) user.streak = data.streak;
    if (data.avgScore !== undefined) user.avgScore = data.avgScore;

    user.lastActive = new Date();
    await user.save();

    res.json({ success: true, data: user });
  } catch (error) {
    console.error('Progress save error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// ──── Save Quiz Score ────
app.post('/api/scores', async (req, res) => {
  try {
    const { email, type, score, difficulty } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    if (type === 'quiz') {
      user.quizScores.push({ score, difficulty });
    } else if (type === 'coding') {
      user.codingResults.push({ score });
    } else if (type === 'aptitude') {
      user.aptitudeScores.push({ score });
    }

    // Recalculate average score
    const allScores = [
      ...user.quizScores.map(s => s.score),
      ...user.codingResults.map(s => s.score),
      ...user.aptitudeScores.map(s => s.score)
    ];
    user.avgScore = allScores.length > 0
      ? Math.round(allScores.reduce((a, b) => a + b, 0) / allScores.length)
      : 0;

    await user.save();
    res.json({ success: true, data: user });
  } catch (error) {
    console.error('Score save error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// ──── Admin Endpoint: Get All Users ────
app.get('/api/admin/users', async (req, res) => {
  try {
    const users = await User.find({}).sort({ createdAt: -1 });
    res.json({ success: true, count: users.length, data: users });
  } catch (error) {
    console.error('Admin Fetch Users Error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// ──── Fallback: serve frontend ────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

// ──── Start Server ────
app.listen(PORT, () => {
  console.log(`\n  ✅ LearnPath server running at http://localhost:${PORT}`);
  console.log(`  📘 API endpoints available at http://localhost:${PORT}/api`);
  console.log(`  🤖 Gemini AI: ${process.env.GEMINI_API_KEY ? 'Configured' : 'Not configured'}`);
  console.log(`  🗄️  MongoDB: Connecting...\n`);
});
