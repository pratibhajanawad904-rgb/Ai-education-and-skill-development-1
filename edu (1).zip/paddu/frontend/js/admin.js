// Admin logic to fetch and display members

document.addEventListener('DOMContentLoaded', fetchUsers);

async function fetchUsers() {
  const tbody = document.getElementById('usersTableBody');
  const countEl = document.getElementById('totalUsersCount');

  try {
    const res = await fetch('/api/admin/users');
    const data = await res.json();

    if (!data.success) {
      throw new Error(data.message || 'Failed to load users');
    }

    const users = data.data;
    countEl.textContent = users.length;

    if (users.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="loading-state">No members found in the database.</td></tr>`;
      return;
    }

    tbody.innerHTML = ''; // Clear loading

    users.forEach(user => {
      const tr = document.createElement('tr');
      
      // Formatting
      const goalBadge = user.goal ? `<span class="badge ${user.goal}">${formatGoal(user.goal)}</span>` : '<span class="badge">None selected</span>';
      const scoreColor = user.avgScore >= 80 ? 'var(--success)' : (user.avgScore >= 50 ? 'var(--warning)' : 'var(--danger)');
      const joinedDate = new Date(user.createdAt).toLocaleDateString();

      tr.innerHTML = `
        <td style="font-weight: 500;">${user.name}</td>
        <td style="color: var(--text-secondary);">${user.email}</td>
        <td>${goalBadge}</td>
        <td style="text-transform: capitalize;">${user.skillLevel || '-'}</td>
        <td>${user.lessonsCompleted || 0} / ${user.totalLessons || 40}</td>
        <td style="font-weight: 600; color: ${scoreColor}">${user.avgScore || 0}%</td>
        <td style="color: var(--text-secondary);">${joinedDate}</td>
      `;
      tbody.appendChild(tr);
    });

  } catch (err) {
    console.error(err);
    tbody.innerHTML = `<tr><td colspan="7" class="loading-state" style="color: var(--danger);">Error loading members: ${err.message}. Make sure the node server is running!</td></tr>`;
  }
}

function formatGoal(goal) {
  if (goal === 'webdev') return 'Web Dev';
  if (goal === 'datascience') return 'Data Science';
  if (goal === 'aiml') return 'AI / ML';
  return goal;
}
