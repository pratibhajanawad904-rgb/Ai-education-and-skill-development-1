/* ========================================
   LearnPath — Progress Dashboard
   Initializes and updates dashboard data
   ======================================== */

function initDashboard(data) {
  if (!data) data = getAppData();
  if (!data) return;

  updateProgressRings(data);
  updateStreak(data);
}

// ──── Update Progress Rings ────
function updateProgressRings(data) {
  const lessonsPercent = Math.round((data.lessonsCompleted / data.totalLessons) * 100);
  const circumference = 2 * Math.PI * 34; // r=34

  // Lessons ring
  const lessonsRing = document.querySelector('#lessonsRing .ring-fill');
  const lessonsText = document.querySelector('#lessonsRing .ring-text');
  if (lessonsRing) {
    const offset = circumference - (lessonsPercent / 100) * circumference;
    lessonsRing.style.strokeDashoffset = offset;
    lessonsText.textContent = `${lessonsPercent}%`;
  }

  // Score ring
  const scoreRing = document.querySelector('#scoreRing .ring-fill');
  const scoreText = document.querySelector('#scoreRing .ring-text');
  if (scoreRing) {
    const offset = circumference - (data.avgScore / 100) * circumference;
    scoreRing.style.strokeDashoffset = offset;
    scoreText.textContent = `${data.avgScore}%`;
  }

  // Update stat values
  const lessonsStat = document.querySelector('#page-dashboard .stat-card:first-child .stat-value');
  if (lessonsStat) {
    lessonsStat.textContent = `${data.lessonsCompleted} / ${data.totalLessons}`;
  }

  // Update Achievement logic
  updateAchievements(data);
}

// ──── Achievement Tracking ────
function updateAchievements(data) {
  const container = document.getElementById('achievementList');
  if (!container) return;

  const milestonesStat = document.getElementById('milestonesValue');
  let achievementCount = 0;

  let html = '';
  
  // 1. First Task Achievement
  if (data.completedTasks && data.completedTasks.length >= 1) {
    achievementCount++;
    html += `<div class="achievement-item"><i data-lucide="zap" style="color:#f59e0b; width:16px; margin-right:8px;"></i> Quick Starter: First task completed!</div>`;
  }

  // 2. 5 Tasks Achievement
  if (data.completedTasks && data.completedTasks.length >= 5) {
    achievementCount++;
    html += `<div class="achievement-item"><i data-lucide="award" style="color:#0ea5e9; width:16px; margin-right:8px;"></i> Rising Star: 5 tasks finished.</div>`;
  }

  // 3. Perfect Quiz Score Achievement
  if (data.quizScores && data.quizScores.some(s => s.score >= 90)) {
    achievementCount++;
    html += `<div class="achievement-item"><i data-lucide="brain" style="color:#10b981; width:16px; margin-right:8px;"></i> Genius: Scored 90%+ in a quiz!</div>`;
  }

  // 4. Streak Achievement
  if (data.streak >= 7) {
    achievementCount++;
    html += `<div class="achievement-item"><i data-lucide="flame" style="color:#ef4444; width:16px; margin-right:8px;"></i> Unstoppable: 7 day streak!</div>`;
  }

  if (milestonesStat) milestonesStat.textContent = achievementCount;
  container.innerHTML = html || `<p class="text-muted" style="font-size:0.9rem;">Start completing tasks to unlock achievement badges!</p>`;
  if (window.lucide) window.lucide.createIcons();
}

// ──── Update Streak Display ────
function updateStreak(data) {
  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const streakContainer = document.querySelector('.streak-display');
  if (!streakContainer) return;

  streakContainer.innerHTML = '';
  days.forEach((day, i) => {
    const span = document.createElement('span');
    span.className = `streak-day ${i < data.streak ? 'active' : 'inactive'}`;
    span.textContent = day;
    streakContainer.appendChild(span);
  });
}

// ──── Animate Bars on Page Load ────
// Use an IntersectionObserver to animate bars when the dashboard becomes visible
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bars = entry.target.querySelectorAll('.bar');
        bars.forEach((bar, i) => {
          const h = bar.style.height;
          bar.style.height = '0%';
          setTimeout(() => {
            bar.style.height = h;
          }, i * 100 + 200);
        });
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.3 });

  document.addEventListener('DOMContentLoaded', () => {
    const chart = document.getElementById('skillChart');
    if (chart) observer.observe(chart);
  });
}
