/* ========================================
   LearnPath — AI Mentor Chatbot
   Powered by Google Gemini AI
   With local fallback for offline use
   ======================================== */

let chatOpen = false;

// Gemini API Configuration
const GEMINI_API_KEY = 'AIzaSyAOW9fJi7c6wjLU1aWRP291UgSvdN91NCQ';
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

// System prompt for the AI mentor
const SYSTEM_PROMPT = `You are "LearnPath AI Mentor", a friendly, supportive, and knowledgeable coding tutor and career mentor for students learning programming. 

Your personality:
- Warm, encouraging, and patient like a real human mentor
- You explain things in simple, clear language with examples
- You use emojis sometimes to keep it friendly (but not too many)
- You keep responses concise (2-4 short paragraphs max)
- You motivate students when they feel stuck or overwhelmed

Your expertise:
- Programming (Python, JavaScript, HTML, CSS, SQL, React, etc.)
- Data Science, Machine Learning, and AI concepts
- Web Development (frontend and backend)
- Career guidance in tech (jobs, skills, certifications, projects)
- Study tips, time management, and learning strategies

Rules:
- Always be supportive and never make the student feel bad
- Give practical examples when explaining code concepts
- If asked about non-tech topics, gently redirect to learning
- Suggest resources when relevant (freeCodeCamp, MDN, Coursera, etc.)
- Keep code examples short and well-commented
- End responses with a helpful follow-up question or encouraging note`;

// Chat history for Gemini context
let chatHistory = [];

function initChat() {
  const messages = document.getElementById('chatMessages');
  messages.innerHTML = '';
  chatHistory = [];

  addBotMessage("Hi there! I'm your AI Mentor, powered by Google Gemini. I can help you with coding concepts, study tips, career advice, or just motivate you when you feel stuck. What's on your mind?");
}

// ──── Toggle Chat Window ────
function toggleChat() {
  chatOpen = !chatOpen;
  const win = document.getElementById('chatWindow');
  const toggle = document.getElementById('chatToggle');

  if (chatOpen) {
    win.classList.add('open');
    toggle.textContent = '✕';
    document.getElementById('chatInput').focus();
  } else {
    win.classList.remove('open');
    toggle.textContent = '💬';
  }
}

// ──── Send Message ────
async function sendChatMessage() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text) return;

  addUserMessage(text);
  input.value = '';

  // Show typing indicator
  showTyping();

  // Try Gemini API first, fall back to local responses
  try {
    const response = await callGeminiAPI(text);
    hideTyping();
    addBotMessage(response);
  } catch (error) {
    console.warn('Gemini API unavailable, using local fallback:', error.message);
    // Fallback: simulate delay then use local response
    setTimeout(() => {
      hideTyping();
      const response = generateLocalResponse(text);
      addBotMessage(response);
    }, 800);
  }
}

function handleChatKey(e) {
  if (e.key === 'Enter') sendChatMessage();
}

function sendSuggestion(text) {
  document.getElementById('chatInput').value = text;
  sendChatMessage();
}

// ──── Gemini API Call ────
async function callGeminiAPI(userMessage) {
  // Add to history
  chatHistory.push({ role: 'user', parts: [{ text: userMessage }] });

  // Build request with system instruction and history
  const requestBody = {
    system_instruction: {
      parts: [{ text: SYSTEM_PROMPT }]
    },
    contents: chatHistory,
    generationConfig: {
      temperature: 0.7,
      topP: 0.9,
      topK: 40,
      maxOutputTokens: 500
    },
    safetySettings: [
      { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
      { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
      { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
      { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
    ]
  };

  const response = await fetch(GEMINI_API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }

  const data = await response.json();

  // Extract text from response
  const aiText = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!aiText) {
    throw new Error('No response text from Gemini');
  }

  // Add AI response to history (keep last 20 messages for context)
  chatHistory.push({ role: 'model', parts: [{ text: aiText }] });
  if (chatHistory.length > 20) {
    chatHistory = chatHistory.slice(-20);
  }

  // Convert markdown-ish formatting to HTML
  return formatAIResponse(aiText);
}

// ──── Format AI Response ────
function formatAIResponse(text) {
  return text
    // Bold: **text** → <strong>text</strong>
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic: *text* → <em>text</em>
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Inline code: `code` → <code>code</code>
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // Code blocks: ```code``` → <code>code</code>
    .replace(/```[\w]*\n?([\s\S]*?)```/g, '<br><code style="display:block; background:#1e1e2e; color:#cdd6f4; padding:8px 12px; border-radius:6px; margin:6px 0; font-size:0.82rem; white-space:pre-wrap;">$1</code>')
    // Line breaks
    .replace(/\n/g, '<br>');
}

// ──── Add Messages ────
function addUserMessage(text) {
  const container = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-message user';
  div.textContent = text;
  container.appendChild(div);
  scrollChat();
}

function addBotMessage(text) {
  const container = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-message bot';
  div.innerHTML = text;
  container.appendChild(div);
  scrollChat();
}

// ──── Typing Indicator ────
function showTyping() {
  const container = document.getElementById('chatMessages');
  const typing = document.createElement('div');
  typing.className = 'typing-indicator';
  typing.id = 'typingIndicator';
  typing.innerHTML = '<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>';
  container.appendChild(typing);
  scrollChat();
}

function hideTyping() {
  const el = document.getElementById('typingIndicator');
  if (el) el.remove();
}

function scrollChat() {
  const container = document.getElementById('chatMessages');
  container.scrollTop = container.scrollHeight;
}

// ──── Local Fallback Response Generator ────
// Used when Gemini API is unavailable (offline, quota exceeded, etc.)
function generateLocalResponse(input) {
  const lower = input.toLowerCase();

  if (lower.match(/\b(hi|hello|hey|greetings)\b/)) {
    return "Hello! Great to see you here. How can I help you today? Feel free to ask me anything about programming, career guidance, or study tips.";
  }

  if (lower.includes('loop') || lower.includes('for loop') || lower.includes('while loop')) {
    return `<strong>Loops</strong> let you repeat a block of code multiple times.<br><br>
    <strong>For loop</strong> — Use when you know how many times to repeat:<br>
    <code>for i in range(5): print(i)</code><br><br>
    <strong>While loop</strong> — Use when you repeat until a condition is false:<br>
    <code>while x > 0: x -= 1</code><br><br>
    <strong>Note:</strong> <em>Start with for loops — they're easier and more common!</em>`;
  }

  if (lower.includes('variable') || lower.includes('variables')) {
    return `<strong>Variables</strong> are containers that store data values.<br><br>
    In Python: <code>name = "Riya"</code><br>
    In JavaScript: <code>let name = "Riya";</code><br><br>
    <strong>Tip:</strong> <em>Use descriptive names like <code>studentAge</code> instead of <code>x</code>!</em>`;
  }

  if (lower.includes('function') || lower.includes('def ')) {
    return `A <strong>function</strong> is a reusable block of code.<br><br>
    Python: <code>def greet(name): return f"Hello, {name}!"</code><br>
    JavaScript: <code>function greet(name) { return "Hello, " + name; }</code><br><br>
    <strong>Tip:</strong> <em>Break your code into small functions — easier to debug!</em>`;
  }

  if (lower.includes('stuck') || lower.includes('confused') || lower.includes('overwhelmed')) {
    return "It's completely normal to feel stuck! Here's what I suggest:<br><br>1. <strong>Take a 5-minute break</strong><br>2. <strong>Review the last concept</strong> you understood<br>3. <strong>Break the problem into smaller parts</strong><br><br>You're doing great by showing up. That's what matters!";
  }

  if (lower.includes('tip') || lower.includes('advice')) {
    const tips = [
      "<strong>Coding Tip:</strong> Write code every day, even 15 minutes. Use <em>Codewars</em> or <em>LeetCode</em> for practice.",
      "<strong>Study Tip:</strong> Use the <strong>Pomodoro Technique</strong> — 25 min study, 5 min break.",
      "<strong>Career Tip:</strong> Build projects, not just tutorials. Employers care about what you can <em>create</em>."
    ];
    return tips[Math.floor(Math.random() * tips.length)];
  }

  if (lower.includes('python')) {
    return "<strong>Python</strong> is great for beginners! Clean, readable, and used in web dev, data science, AI.<br><br><strong>Tip:</strong> <em>Start with basics, then pick: web dev (Django), data science (Pandas), or AI (TensorFlow).</em>";
  }

  if (lower.includes('javascript') || lower.includes('react')) {
    return "<strong>JavaScript</strong> is the language of the web! Learn DOM manipulation, async/await, and frameworks like React.<br><br><strong>Tip:</strong> <em>Build small projects like a calculator or to-do list to practice!</em>";
  }

  if (lower.includes('career') || lower.includes('job')) {
    return "In-demand tech roles: <strong>Frontend Dev</strong>, <strong>Data Scientist</strong>, <strong>ML Engineer</strong>, <strong>Full-Stack Dev</strong>.<br><br><strong>Note:</strong> <em>Build a portfolio with 3-4 solid projects — that matters more than certificates!</em>";
  }

  // Default
  return "That's a great question! I'd love to help. Could you give me more detail? For example:<br>• A specific coding problem?<br>• A concept to explain?<br>• Study or career advice?<br><br><strong>Tip:</strong> <em>Ask me about loops, functions, arrays, CSS, Python, career paths, or anything else!</em>";
}
