/* ========================================
   LearnPath — Main Application Logic
   Handles: login, navigation, learning path
   ======================================== */

// ──── State ────
const APP_KEY = 'learnpath_data';

function getAppData() {
  const raw = localStorage.getItem(APP_KEY);
  return raw ? JSON.parse(raw) : null;
}

function saveAppData(data) {
  localStorage.setItem(APP_KEY, JSON.stringify(data));
}

function defaultData(name, email) {
  return {
    user: { name, email },
    goal: null,
    skillLevel: null,
    hoursPerWeek: null,
    roadmap: null,
    completedTasks: [],
    quizScores: [],
    codingResults: [],
    aptitudeScores: [],
    lessonsCompleted: 0,
    totalLessons: 40,
    streak: 0,
    milestones: 0,
    avgScore: 0,
    createdAt: new Date().toISOString()
  };
}

// ──── Initialization ────
document.addEventListener('DOMContentLoaded', () => {
  const data = getAppData();
  const splash = document.getElementById('splash-screen');
  
  if (splash) {
    // If splash exists, wait for it to finish before showing content
    setTimeout(() => {
      if (data && data.user) {
        showApp(data);
      } else {
        showLogin();
      }
    }, 3800); // Wait for splash (3.5s) + slight fade buffer
  } else {
    // Immediate show if no splash
    if (data && data.user) {
      showApp(data);
    } else {
      showLogin();
    }
  }

  // Login handler
  const loginForm = document.getElementById('loginForm');
  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('loginName').value.trim();
    const email = document.getElementById('loginEmail').value.trim();
    if (name && email) {
      const data = defaultData(name, email);
      saveAppData(data);
      showApp(data);
    }
  });

  // Nav hamburger
  document.getElementById('navHamburger').addEventListener('click', () => {
    document.getElementById('navLinks').classList.toggle('open');
  });

  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem(APP_KEY);
    showLogin();
  });

  // Nav links
  document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      navigateTo(page);
    });
  });

  // Nav history listeners
  document.getElementById('navBack').addEventListener('click', goBack);
  document.getElementById('navForward').addEventListener('click', goForward);
});

// ──── Show / Hide ────
function showLogin() {
  document.getElementById('loginPage').classList.remove('hidden');
  document.getElementById('appShell').classList.add('hidden');
}

function showApp(data) {
  document.getElementById('loginPage').classList.add('hidden');
  document.getElementById('appShell').classList.remove('hidden');

  // Set user info
  const name = data.user.name;
  const first = name.split(' ')[0];
  document.getElementById('userName').textContent = first;
  document.getElementById('userAvatar').textContent = first.charAt(0).toUpperCase();

  // Welcome
  const hour = new Date().getHours();
  let greeting = 'Good morning';
  if (hour >= 12 && hour < 17) greeting = 'Good afternoon';
  else if (hour >= 17) greeting = 'Good evening';
  document.getElementById('welcomeMsg').textContent = `${greeting}, ${first}!`;

  // Home stats
  document.getElementById('homeLessons').textContent = `${data.lessonsCompleted}/${data.totalLessons}`;
  document.getElementById('homeScore').textContent = `${data.avgScore}%`;
  document.getElementById('homeStreak').textContent = `${data.streak}`;

  // Set motivational messages (rotate)
  setMotivation(data);

  // If goal already set, show roadmap
  if (data.goal) {
    showRoadmap(data);
  }

  // Initialize modules
  if (typeof initChat === 'function') initChat();
  if (typeof initAssessments === 'function') initAssessments();
  if (typeof initDashboard === 'function') initDashboard(data);
}

// ──── Navigation ────
let navHistory = ['home'];
let historyIndex = 0;

function navigateTo(page, fromHistory = false) {
  // Hide all sections
  document.querySelectorAll('.page-section').forEach(sec => sec.classList.remove('active'));

  // Show target
  const target = document.getElementById(`page-${page}`);
  if (target) target.classList.add('active');

  // Update nav active
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  const navLink = document.querySelector(`.nav-links a[data-page="${page}"]`);
  if (navLink) navLink.classList.add('active');

  // History tracking
  if (!fromHistory) {
    if (historyIndex < navHistory.length - 1) {
      navHistory = navHistory.slice(0, historyIndex + 1);
    }
    if (navHistory[navHistory.length - 1] !== page) {
      navHistory.push(page);
      historyIndex = navHistory.length - 1;
    }
  }
  updateNavArrows();

  // Close mobile nav
  document.getElementById('navLinks').classList.remove('open');
}

function updateNavArrows() {
  const backBtn = document.getElementById('navBack');
  const forwardBtn = document.getElementById('navForward');
  if (backBtn) backBtn.disabled = historyIndex === 0;
  if (forwardBtn) forwardBtn.disabled = historyIndex === navHistory.length - 1;
}

function goBack() {
  if (historyIndex > 0) {
    historyIndex--;
    navigateTo(navHistory[historyIndex], true);
  }
}

function goForward() {
  if (historyIndex < navHistory.length - 1) {
    historyIndex++;
    navigateTo(navHistory[historyIndex], true);
  }
}

// ──── Motivational Messages ────
const motivationalMessages = [
  "You've studied {streak} days in a row — keep going! Consistency is the key to mastery.",
  "Great learners are made by daily practice. You're on the right track!",
  "Every expert was once a beginner. Keep pushing forward!",
  "You're {percent}% through your learning path. Almost there!",
  "Small steps every day lead to big results. You've got this!",
  "Learning is a marathon, not a sprint. Proud of your progress!",
  "Riya finished the HTML module yesterday — will you complete yours today?",
  "Tip: Try explaining what you learned to a friend — it deepens understanding."
];

function setMotivation(data) {
  const bar = document.getElementById('motivationBar');
  const idx = Math.floor(Math.random() * motivationalMessages.length);
  let msg = motivationalMessages[idx];
  msg = msg.replace('{streak}', data.streak);
  msg = msg.replace('{percent}', Math.round((data.lessonsCompleted / data.totalLessons) * 100));
  bar.innerHTML = `<span class="icon"></span><span>${msg}</span>`;
}

// ──── Learning Path — Goal Selection ────
let selectedGoal = null;

function selectGoal(el) {
  document.querySelectorAll('.goal-option').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  selectedGoal = el.getAttribute('data-goal');
}

function generateRoadmap() {
  const level = document.getElementById('skillLevel').value;
  const hours = document.getElementById('hoursPerWeek').value;

  if (!selectedGoal) { alert('Please select a career goal.'); return; }
  if (!level) { alert('Please select your skill level.'); return; }
  if (!hours) { alert('Please select hours per week.'); return; }

  const data = getAppData();
  data.goal = selectedGoal;
  data.skillLevel = level;
  data.hoursPerWeek = parseInt(hours);
  data.roadmap = buildRoadmap(selectedGoal, level, parseInt(hours));
  saveAppData(data);

  showRoadmap(data);
}

function showRoadmap(data) {
  document.getElementById('goalSetup').classList.add('hidden');
  document.getElementById('roadmapSection').classList.remove('hidden');

  const goalNames = { 
    webdev: 'Web Development', 
    datascience: 'Data Science', 
    aiml: 'AI / Machine Learning',
    embedded: 'Embedded Systems',
    vlsi: 'VLSI Design',
    iot: 'IoT Engineering'
  };
  document.getElementById('roadmapTitle').textContent = `Your ${goalNames[data.goal]} Roadmap`;
  document.getElementById('roadmapSubtitle').textContent =
    `${capitalize(data.skillLevel)} · ~${data.hoursPerWeek} hrs/week · ${data.roadmap.length}-week plan`;

  renderRoadmap(data);
}

function resetGoal() {
  const data = getAppData();
  data.goal = null;
  data.roadmap = null;
  data.completedTasks = [];
  selectedGoal = null;
  saveAppData(data);

  document.getElementById('goalSetup').classList.remove('hidden');
  document.getElementById('roadmapSection').classList.add('hidden');
  document.querySelectorAll('.goal-option').forEach(o => o.classList.remove('selected'));
}

// ──── Build Roadmap Data ────
function buildRoadmap(goal, level, hours) {
  const roadmaps = {
    webdev: [
      { week: 1, title: 'HTML Foundations', tasks: [
        { text: 'Tags & Attributes', resource: 'https://developer.mozilla.org/en-US/docs/Learn/HTML/Introduction_to_HTML/Getting_started', video: 'https://www.youtube.com/watch?v=kUMe1FH4CHE' },
        { text: 'Semantic HTML5', resource: 'https://developer.mozilla.org/en-US/docs/Glossary/Semantics#semantics_in_html', video: 'https://www.youtube.com/watch?v=pQN-pnXPaVg' },
        { text: 'Form Elements & Validation', resource: 'https://developer.mozilla.org/en-US/docs/Learn/Forms', video: 'https://www.youtube.com/watch?v=fNcJuPIZ2BA' }
      ], extra: [
        { text: 'Deep Dive: Accessibility (A11y)', resource: 'https://www.w3.org/WAI/fundamentals/accessibility-intro/', video: 'https://www.youtube.com/watch?v=cOMehuVJXas' }
      ]},
      { week: 2, title: 'CSS Styling Essentials', tasks: [
        { text: 'Box Model & Specificity', resource: 'https://web.dev/learn/css/box-model/', video: 'https://www.youtube.com/watch?v=yfoY53QXEnI' },
        { text: 'Flexbox Layouts', resource: 'https://css-tricks.com/snippets/css/a-guide-to-flexbox/', video: 'https://www.youtube.com/watch?v=JJSoGo8JSKQ' },
        { text: 'CSS Variables & Themes', resource: 'https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties', video: 'https://www.youtube.com/watch?v=Nt96fO_AUnk' }
      ], extra: [
        { text: 'Challenge: Card Layout Build', resource: 'https://www.frontendmentor.io/challenges', video: '' }
      ]},
      { week: 3, title: 'Advanced CSS & Responsive', tasks: [
        { text: 'CSS Grid System', resource: 'https://css-tricks.com/snippets/css/complete-guide-grid/', video: 'https://www.youtube.com/watch?v=rg7Fvvl39u0' },
        { text: 'Media Queries & Mobile-First', resource: 'https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Responsive_Design', video: 'https://www.youtube.com/watch?v=yU7jJ3NbPdA' }
      ], extra: [
        { text: 'Animations & Transitions', resource: 'https://animista.net/', video: 'https://www.youtube.com/watch?v=S-En_0WBeKc' }
      ]},
      { week: 4, title: 'JavaScript Essentials', tasks: [
        { text: 'ES6+ Syntax (Let/Const)', resource: 'https://javascript.info/var-let-const', video: 'https://www.youtube.com/watch?v=upDLs1S7S8s' },
        { text: 'Functions & Scope', resource: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions', video: 'https://www.youtube.com/watch?v=fNcJuPIZ2BA' }
      ], extra: [
        { text: 'Deep Dive: Prototype & Classes', resource: '', video: '' }
      ]},
      { week: 5, title: 'DOM Handling', tasks: [
        { text: 'Event Listeners', resource: 'https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Building_blocks/Events', video: 'https://www.youtube.com/watch?v=y17RuWkWdn8' },
        { text: 'Input Handling', resource: 'https://javascript.info/form-elements', video: '' }
      ], extra: [
        { text: 'Project: To-Do List App', resource: 'https://www.freecodecamp.org/news/build-a-todo-app-with-javascript-vanilla-js-tutorial/', video: '' }
      ]},
      { week: 6, title: 'Modern JS: Async/APIs', tasks: [
        { text: 'Promises & Fetch API', resource: 'https://javascript.info/promise-basics', video: 'https://www.youtube.com/watch?v=drK679uXkxA' },
        { text: 'Async/Await Logic', resource: 'https://javascript.info/async-await', video: 'https://www.youtube.com/watch?v=V9ko-Z6u66s' }
      ], extra: [
        { text: 'Deep Dive: Error Handling', resource: 'https://javascript.info/try-catch', video: '' }
      ]},
      { week: 7, title: 'Frontend Frameworks (React)', tasks: [
        { text: 'Components & Props', resource: 'https://react.dev/learn/passing-props-to-a-component', video: 'https://www.youtube.com/watch?v=hQAHSlTtcmY' },
        { text: 'State & Hooks (useState)', resource: 'https://react.dev/learn/state-a-components-memory', video: 'https://www.youtube.com/watch?v=O6P86uwfdE0' }
      ], extra: [
        { text: 'React Router Intro', resource: 'https://reactrouter.com/en/main/start/tutorial', video: '' }
      ]},
      { week: 8, title: 'Web Project Mastery', tasks: [
        { text: 'Final Portfolio Build', resource: 'https://www.codewell.dev/', video: 'https://www.youtube.com/watch?v=2HBIzre2Z_M' },
        { text: 'Netlify/Vercel Deployment', resource: 'https://docs.netlify.com/site-deploys/create-deploys/', video: '' }
      ], extra: [
        { text: 'Optimization & SEO Audit', resource: 'https://developers.google.com/search/docs/fundamentals/seo-starter-guide', video: '' }
      ]}
    ],
    embedded: [
      { week: 1, title: 'Embedded C Fundamentals', tasks: [
        { text: 'Pointers & Memory mapping', resource: 'https://embeddedgurus.com/stack-overflow/2011/02/efficient-c-tip-1-use-the-right-data-type/', video: 'https://www.youtube.com/watch?v=2ybLD6_2gKM' },
        { text: 'Bitwise Manipulation', resource: 'https://pvs-studio.com/en/blog/posts/cpp/0961/', video: 'https://www.youtube.com/watch?v=jlQmyfPrH_Y' }
      ], extra: [
        { text: 'Memory Management Strategy', resource: 'https://barrgroup.com/embedded-systems/how-to/malloc-free-dynamic-memory-allocation', video: '' }
      ]},
      { week: 2, title: 'MCU Peripherals', tasks: [
        { text: 'GPIO Port Controls', resource: 'https://www.st.com/resource/en/application_note/an4899-stm32-gpio-configuration-for-hardware-settings-and-lowpower-consumption-stmicroelectronics.pdf', video: 'https://www.youtube.com/watch?v=vL3uMvNOf3A' },
        { text: 'Interrupts & Handling', resource: 'https://www.digikey.com/en/maker/projects/introduction-to-rtos-interrupt-management/60824fe5d2f342798e29a9ed7db638e7', video: 'https://www.youtube.com/watch?v=uV6S2-uMFSY' }
      ], extra: [
        { text: 'Deep Dive: NVIC Architecture', resource: 'https://developer.arm.com/documentation/100699/0101/Interrupt-Controller/Nested-Vectored-Interrupt-Controller--NVIC-', video: '' }
      ]},
      { week: 3, title: 'Communication Protocols', tasks: [
        { text: 'UART Serial Comms', resource: 'https://learn.sparkfun.com/tutorials/serial-communication/all', video: 'https://www.youtube.com/watch?v=ll-K1xswMzk' },
        { text: 'I2C Master/Slave', resource: 'https://www.circuitbasics.com/basics-of-the-i2c-communication-protocol/', video: 'https://www.youtube.com/watch?v=kf6_ZIn-n_A' }
      ], extra: [
        { text: 'SPI Protocol implementation', resource: 'https://www.analog.com/en/analog-dialogue/articles/introduction-to-spi-interface.html', video: '' }
      ]},
      { week: 4, title: 'Timers & PWM', tasks: [
        { text: 'Hardware Timers', resource: 'https://embedded-lab.com/blog/mcu-timers/', video: 'https://www.youtube.com/watch?v=IHZwWFHWa-w' },
        { text: 'PWM Generation for LEDs', resource: 'https://www.embedded.com/pulse-width-modulation-basics/', video: 'https://www.youtube.com/watch?v=vVj2itVNku4' }
      ], extra: [
        { text: 'Frequency Measurement', resource: 'https://www.digikey.com/en/articles/how-to-use-microcontroller-timer-counter-peripherals', video: '' }
      ]},
      { week: 5, title: 'ADC & Sensors', tasks: [
        { text: 'Analog Interfacing', resource: 'https://www.allaboutcircuits.com/technical-articles/introduction-to-the-analog-to-digital-converter-adc/', video: 'https://www.youtube.com/watch?v=fNcJuPIZ2BA' }
      ], extra: [
        { text: 'DMA for Data transfer', resource: 'https://www.st.com/resource/en/application_note/an4031-using-the-stm32f2-stm32f4-and-stm32f7-series-dma-controller-stmicroelectronics.pdf', video: '' }
      ]},
      { week: 6, title: 'RTOS Principles', tasks: [
        { text: 'FreeRTOS Tasking', resource: 'https://www.freertos.org/task-notifications-stay-responsive.html', video: 'https://www.youtube.com/watch?v=vVj2itVNku4' }
      ], extra: [
        { text: 'Semaphores & Mutexes', resource: 'https://www.freertos.org/Real-time-embedded-RTOS-mutexes.html', video: '' }
      ]},
      { week: 7, title: 'Low Power Optimization', tasks: [
        { text: 'Power Management (Sleep)', resource: 'https://www.silabs.com/whitepapers/low-power-design-guide', video: '' }
      ], extra: [
        { text: 'Battery Life Calculation', resource: 'https://www.digikey.com/en/resources/conversion-calculators/conversion-calculator-battery-life', video: '' }
      ]},
      { week: 8, title: 'Embedded Capstone', tasks: [
        { text: 'Integrated System Project', resource: 'https://github.com/topics/embedded-project', video: '' }
      ], extra: [
        { text: 'Firmware Documentation', resource: 'https://doxygen.nl/manual/docblocks.html', video: '' }
      ]}
    ],
    vlsi: [
      { week: 1, title: 'Digital Logic design', tasks: [
        { text: 'Boolean Logic & Gates', resource: 'https://www.electronics-tutorials.ws/logic/logic_1.html', video: 'https://www.youtube.com/watch?v=fNcJuPIZ2BA' },
        { text: 'Gates & K-Maps Design', resource: 'https://www.tutorialspoint.com/digital_circuits/digital_circuits_k_map_method.htm', video: 'https://www.youtube.com/watch?v=yfoY53QXEnI' }
      ], extra: [
        { text: 'Quine-McCluskey Method', resource: 'https://www.geeksforgeeks.org/quine-mccluskey-method/', video: '' }
      ]},
      { week: 2, title: 'Verilog RTL coding', tasks: [
        { text: 'Verilog Syntax & Logic', resource: 'https://www.chipverify.com/verilog/verilog-tutorial', video: 'https://www.youtube.com/watch?v=rg7Fvvl39u0' },
        { text: 'Testbench creation skills', resource: 'https://www.asic-world.com/verilog/veritut1.html', video: 'https://www.youtube.com/watch?v=upDLs1S7S8s' }
      ], extra: [
        { text: 'Finite State Machines RTL', resource: 'https://vlsiverify.com/verilog/verilog-fsm/', video: '' }
      ]},
      { week: 3, title: 'Sequential Logic', tasks: [
        { text: 'Registers & Latches', resource: 'https://www.elprocus.com/difference-between-latch-and-flip-flop/', video: 'https://www.youtube.com/watch?v=yU7jJ3NbPdA' }
      ], extra: [
        { text: 'Clocking Strategies', resource: 'https://www.allaboutcircuits.com/technical-articles/understanding-clock-signals-and-clock-generation-in-fpga-designs/', video: '' }
      ]},
      { week: 4, title: 'FPGA Design Flow', tasks: [
        { text: 'LUT & Configurable blocks', resource: 'https://www.xilinx.com/support/documentation/university/Vivado-Education-Resources/Vivado-Introductory-Workshops/FPGA-Architecture-Basics.pdf', video: 'https://www.youtube.com/watch?v=mD0VlV29fP0' }
      ], extra: [
        { text: 'Synthesis Constraints', resource: 'https://www.intel.com/content/www/us/en/docs/programmable/683082/21-3/timing-constraints.html', video: '' }
      ]},
      { week: 5, title: 'Physical Design Flow', tasks: [
        { text: 'Layout & DRC check', resource: 'https://www.vlsisystemdesign.com/basic-physical-design-flow/', video: '' }
      ], extra: [
        { text: 'LVS Verification', resource: 'https://en.wikipedia.org/wiki/Layout_versus_schematic', video: '' }
      ]},
      { week: 6, title: 'STA Analysis', tasks: [
        { text: 'Setup & Hold Time', resource: 'https://vlsi-expert.com/2011/04/static-timing-analysis-sta-basics-part.html', video: '' }
      ], extra: [
        { text: 'Clock Tree Synthesis (CTS)', resource: 'https://vlsitutorials.com/clock-tree-synthesis-cts-in-physical-design/', video: '' }
      ]},
      { week: 7, title: 'Verification Skills', tasks: [
        { text: 'SystemVerilog/UVM', resource: 'https://www.accellera.org/community/uvm', video: '' }
      ], extra: [
        { text: 'Coverage-Driven Verification', resource: 'https://vlsiverify.com/uvm/functional-coverage/', video: '' }
      ]},
      { week: 8, title: 'VLSI Project', tasks: [
        { text: 'Full IC Integration', resource: 'https://www.semiwiki.com/', video: '' }
      ], extra: [
        { text: 'Final Project Tape-out', resource: 'https://secure.wikimedia.org/wikipedia/en/wiki/Tape-out', video: '' }
      ]}
    ],
    iot: [
      { week: 1, title: 'IoT Ecosystem Intro', tasks: [
        { text: 'Sensors & Architecture', resource: 'https://www.iotforall.com/what-is-iot-architecture', video: 'https://www.youtube.com/watch?v=ll-K1xswMzk' },
        { text: 'NodeMCU & ESP32 Setup', resource: 'https://randomnerdtutorials.com/getting-started-with-esp32/', video: 'https://www.youtube.com/watch?v=Z1Yd7upQsXY' }
      ], extra: [
        { text: 'IoT Protocols Overview', resource: 'https://www.behrtech.com/blog/iot-protocols-and-standards/', video: '' }
      ]},
      { week: 2, title: 'Connectivity Mastery', tasks: [
        { text: 'MQTT & HTTP Protocols', resource: 'https://mqtt.org/getting-started/', video: 'https://www.youtube.com/watch?v=kf6_ZIn-n_A' },
        { text: 'Networking for IoT nodes', resource: 'https://learn.adafruit.com/adafruit-io-basics-wifi', video: 'https://www.youtube.com/watch?v=drK679uXkxA' }
      ], extra: [
        { text: 'CoAP & WebSockets', resource: 'https://dev.to/itnext/the-difference-between-coap-and-mqtt-34d1', video: '' }
      ]},
      { week: 3, title: 'Cloud Data Platforms', tasks: [
        { text: 'Firebase/ThinkSpeak integration', resource: 'https://thingspeak.com/pages/learn_more', video: 'https://www.youtube.com/watch?v=mD0VlV29fP0' }
      ], extra: [
        { text: 'AWS IoT Core Basics', resource: 'https://docs.aws.amazon.com/iot/latest/developerguide/what-is-aws-iot.html', video: '' }
      ]},
      { week: 4, title: 'IoT Security & Privacy', tasks: [
        { text: 'TLS/SSL for IoT endpoints', resource: 'https://hub.digi.com/blog/post/iot-security-basics-tls-and-ssl', video: '' }
      ], extra: [
        { text: 'Firmware Security bits', resource: 'https://www.owasp.org/index.php/IoT_Security_Guidance', video: '' }
      ]},
      { week: 5, title: 'Edge Analytics', tasks: [
        { text: 'Local Processing (ESP32)', resource: 'https://towardsdatascience.com/edge-computing-on-esp32-a7f45778a87b', video: '' }
      ], extra: [
        { text: 'Filter Algorithms (Kalman)', resource: 'https://www.kalmanfilter.net/default.aspx', video: '' }
      ]},
      { week: 6, title: 'IoT Projects (Home)', tasks: [
        { text: 'Smart Home Automation build', resource: 'https://create.arduino.cc/projecthub/projects/tags/home-automation', video: '' }
      ], extra: [
        { text: 'Voice Assist Integration', resource: 'https://developer.amazon.com/en-US/alexa/alexa-skills-kit', video: '' }
      ]},
      { week: 7, title: 'Data Dashboards', tasks: [
        { text: 'Grafana & Data Viz displays', resource: 'https://grafana.com/docs/grafana/latest/getting-started/', video: '' }
      ], extra: [
        { text: 'Mobile Dashboard (Blynk)', resource: 'https://docs.blynk.io/en/getting-started/what-is-blynk', video: '' }
      ]},
      { week: 8, title: 'IoT Final Build', tasks: [
        { text: 'Industrial Prototype deployment', resource: 'https://www.hackster.io/topics/iot', video: '' }
      ], extra: [
        { text: 'LPM Power profiling', resource: 'https://www.nordicsemi.com/Software-and-tools/Development-Tools/Power-Profiler-Kit-2', video: '' }
      ]}
    ],
    datascience: [
      { week: 1, title: 'Python Foundations', tasks: [
        { text: 'Python Installation & Jupyter', resource: 'https://www.anaconda.com/', video: 'https://www.youtube.com/watch?v=5mDYijMfSzs' },
        { text: 'Variables & Data Types', resource: 'https://docs.python.org/3/tutorial/', video: 'https://www.youtube.com/watch?v=Z1Yd7upQsXY' }
      ], extra: [
        { text: 'List Comprehensions Skills', resource: 'https://realpython.com/list-comprehension-python/', video: '' }
      ]},
      { week: 2, title: 'Data Libraries Master', tasks: [
        { text: 'NumPy Vectorized Computing', resource: 'https://numpy.org/doc/', video: 'https://www.youtube.com/watch?v=QUT1VHiLmmI' },
        { text: 'Pandas Dataframes logic', resource: 'https://pandas.pydata.org/docs/', video: 'https://www.youtube.com/watch?v=vmEHCJofslg' }
      ], extra: [
        { text: 'Data Cleaning advanced', resource: 'https://towardsdatascience.com/data-cleaning-with-python-and-pandas-727c6883e5af', video: '' }
      ]},
      { week: 3, title: 'Stats & Visualization', tasks: [
        { text: 'Matplotlib Plots', resource: 'https://matplotlib.org/', video: 'https://www.youtube.com/watch?v=DAQNHzOcO5A' },
        { text: 'Seaborn Heatmaps', resource: 'https://seaborn.pydata.org/', video: 'https://www.youtube.com/watch?v=6GUu6qdz5Dg' }
      ], extra: [
        { text: 'Exploratory Data Analysis (EDA)', resource: 'https://www.kaggle.com/learn/exploratory-data-analysis', video: '' }
      ]},
      { week: 4, title: 'SQL & Database', tasks: [
        { text: 'SQL Data Mastery Queries', resource: 'https://sqlbolt.com/', video: 'https://www.youtube.com/watch?v=7S_tz1z_5bA' }
      ], extra: [
        { text: 'PostgreSQL Advanced Joins', resource: 'https://www.postgresqltutorial.com/postgresql-joins/', video: '' }
      ]},
      { week: 5, title: 'Intro to ML', tasks: [
        { text: 'Linear Regression Maths', resource: 'https://scikit-learn.org/stable/modules/linear_model.html', video: 'https://www.youtube.com/watch?v=u6V5fMofZ2Q' }
      ], extra: [
        { text: 'Gradient Descent Intro', resource: 'https://ml-cheatsheet.readthedocs.io/en/latest/gradient_descent.html', video: '' }
      ]},
      { week: 6, title: 'Advanced ML logic', tasks: [
        { text: 'Random Forest Implementation', resource: 'https://scikit-learn.org/stable/modules/ensemble.html#forests-of-randomized-trees', video: 'https://www.youtube.com/watch?v=vVj2itVNku4' }
      ], extra: [
        { text: 'XGBoost & Tuning', resource: 'https://xgboost.readthedocs.io/en/stable/', video: '' }
      ]},
      { week: 7, title: 'DS Web Deployment', tasks: [
        { text: 'Streamlit for DS Apps', resource: 'https://docs.streamlit.io/', video: 'https://www.youtube.com/watch?v=kf6_ZIn-n_A' }
      ], extra: [
        { text: 'Model Serialization (Pickle)', resource: 'https://docs.python.org/3/library/pickle.html', video: '' }
      ]},
      { week: 8, title: 'Capstone DS Build', tasks: [
        { text: 'End-to-End Data Project', resource: 'https://www.kaggle.com/code', video: '' }
      ], extra: [
        { text: 'GitHub DS Repository Build', resource: 'https://docs.github.com/en/get-started/quickstart/create-a-repo', video: '' }
      ]}
    ],
    aiml: [
      { week: 1, title: 'AI Foundations Basics', tasks: [
        { text: 'Linear Algebra for ML math', resource: 'https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/', video: 'https://www.youtube.com/watch?v=jbs7reS2_3Q' },
        { text: 'Calculus Optimization Gradient', resource: 'https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/', video: 'https://www.youtube.com/watch?v=IHZwWFHWa-w' }
      ], extra: [
        { text: 'Probability & Distributions', resource: 'https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2014/', video: '' }
      ]},
      { week: 2, title: 'Classical ML systems', tasks: [
        { text: 'SVM & Kernel Tricks', resource: 'https://scikit-learn.org/stable/modules/svm.html', video: 'https://www.youtube.com/watch?v=ZmS48XasR0A' }
      ], extra: [
        { text: 'Bias-Variance Tradeoff', resource: 'https://en.wikipedia.org/wiki/Bias%E2%80%93variance_tradeoff', video: '' }
      ]},
      { week: 3, title: 'Neural Networks 101', tasks: [
        { text: 'Backpropagation logic', resource: 'https://neuralnetworksanddeeplearning.com/chap2.html', video: 'https://www.youtube.com/watch?v=Ilg3gGewQ5U' }
      ], extra: [
        { text: 'Activation Functions Deep Dive', resource: 'https://machinelearningmastery.com/choose-an-activation-function-for-deep-learning/', video: '' }
      ]},
      { week: 4, title: 'Computer Vision AI', tasks: [
        { text: 'CNN Architecture flow', resource: 'https://cs231n.github.io/convolutional-networks/', video: 'https://www.youtube.com/watch?v=zfiSAzpy9NM' }
      ], extra: [
        { text: 'Object Detection (YOLO)', resource: 'https://pjreddie.com/darknet/yolo/', video: '' }
      ]},
      { week: 5, title: 'Natural Language Processing', tasks: [
        { text: 'Word Embeddings logic', resource: 'https://web.stanford.edu/class/cs224n/readings/cs224n-2019-notes01-wordvecs1.pdf', video: 'https://www.youtube.com/watch?v=8m9S399_uI4' }
      ], extra: [
        { text: 'RNNs & LSTMs architecture', resource: 'https://colah.github.io/posts/2015-08-Understanding-LSTMs/', video: '' }
      ]},
      { week: 6, title: 'Transformers & Gen AI', tasks: [
        { text: 'Attention Mechanism deep', resource: 'https://jalammar.github.io/illustrated-transformer/', video: 'https://www.youtube.com/watch?v=zxQyTK8S6zI' }
      ], extra: [
        { text: 'LLM Fine-tuning Basics', resource: 'https://huggingface.co/docs/transformers/training', video: '' }
      ]},
      { week: 7, title: 'ML Ops Deployment', tasks: [
        { text: 'Serving Model APIs AI', resource: 'https://fastapi.tiangolo.com/deployment/', video: 'https://www.youtube.com/watch?v=Vp_B_v9m9E8' }
      ], extra: [
        { text: 'Docker for ML Models', resource: 'https://www.docker.com/blog/how-to-deploy-on-remote-docker-hosts-with-docker-compose/', video: '' }
      ]},
      { week: 8, title: 'Portfolio AI Build', tasks: [
        { text: 'End-to-End AI System', resource: 'https://github.com/topics/machine-learning-project', video: '' }
      ], extra: [
        { text: 'AI Ethics & Fairness report', resource: 'https://www.partnershiponai.org/resources/', video: '' }
      ]}
    ]
  };

  let weeks = roadmaps[goal] || roadmaps['webdev'];

  // Adjust roadmap starting point based on skill level
  let startIndex = 0;
  if (level === 'intermediate') startIndex = 2;
  else if (level === 'advanced') startIndex = 4;
  else if (level === 'expert') startIndex = 6;

  // Deep clone to avoid mutating the original roadmap bank
  weeks = JSON.parse(JSON.stringify(weeks)).slice(startIndex);

  // If user chooses high duration (15 or 20+ hours), inject extra sub-topics (the 'extra' field)
  if (hours >= 15) {
    weeks.forEach(week => {
      if (week.extra && week.extra.length > 0) {
        week.tasks = [...week.tasks, ...week.extra];
      }
    });
  }

  return weeks;
}

// ──── Render Roadmap ────
function renderRoadmap(data) {
  const container = document.getElementById('roadmapContainer');
  container.innerHTML = '';

  data.roadmap.forEach((week, idx) => {
    const isCurrent = idx === 0;
    const div = document.createElement('div');
    div.className = `week-card${isCurrent ? ' current' : ''}`;

    let badge = 'upcoming';
    let badgeText = 'Upcoming';
    if (isCurrent) { badge = 'current'; badgeText = 'This Week'; }

    // Check completed tasks
    const completedForWeek = data.completedTasks.filter(t => t.startsWith(`w${week.week}-`));
    if (completedForWeek.length === week.tasks.length && !isCurrent) {
      badge = 'completed'; badgeText = 'Completed ✓';
    }

    let tasksHTML = '';
    week.tasks.forEach((task, ti) => {
      const taskId = `w${week.week}-${ti}`;
      const checked = data.completedTasks.includes(taskId);
      tasksHTML += `
        <li class="task-item${checked ? ' completed' : ''}" style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid var(--border-light);">
          <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
            <input type="checkbox" id="${taskId}" ${checked ? 'checked' : ''} onchange="toggleTask('${taskId}')" style="width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary);" />
            <label for="${taskId}" style="cursor: pointer; font-weight: 500;">${task.text}</label>
          </div>
          <div class="task-resources-row" style="display: flex; gap: 8px;">
            ${task.video ? `<a class="task-resource video-link" href="${task.video}" target="_blank" style="font-size: 0.75rem; color: #ef4444; background: #fee2e2; padding: 4px 10px; border-radius: 6px; font-weight: 600; display: flex; align-items: center; gap: 4px;"><i data-lucide="play-circle" style="width:14px;"></i>Video</a>` : ''}
            ${task.resource ? `<a class="task-resource" href="${task.resource}" target="_blank" style="font-size: 0.75rem; color: var(--primary); background: #eff6ff; padding: 4px 10px; border-radius: 6px; font-weight: 600; display: flex; align-items: center; gap: 4px;"><i data-lucide="file-text" style="width:14px;"></i>Docs</a>` : ''}
          </div>
        </li>`;
    });

    div.innerHTML = `
      <div class="week-header">
        <span class="week-label">Week ${week.week}: ${week.title}</span>
        <span class="week-badge ${badge}">${badgeText}</span>
      </div>
      <ul class="task-list">${tasksHTML}</ul>`;

    container.appendChild(div);
  });
}

// ──── Toggle Task Completion ────
function toggleTask(taskId) {
  const data = getAppData();
  const idx = data.completedTasks.indexOf(taskId);
  if (idx > -1) {
    data.completedTasks.splice(idx, 1);
  } else {
    data.completedTasks.push(taskId);
  }
  // Update lessons completed count
  data.lessonsCompleted = Math.min(data.totalLessons, 12 + data.completedTasks.length);
  saveAppData(data);
  renderRoadmap(data);

  // Update home stats
  document.getElementById('homeLessons').textContent = `${data.lessonsCompleted}/${data.totalLessons}`;
  
  // Re-run dashboard logic if visible
  if (typeof initDashboard === 'function') initDashboard(data);
}

// ──── Helpers ────
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
