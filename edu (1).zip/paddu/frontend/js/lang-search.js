/* ========================================
   LearnPath / eduspark — Custom Language Search
   Controls the hidden Google Translate widget
   ======================================== */

// Common language mapping that Google Translate supports
const supportedLanguages = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'Hindi (हिंदी)' },
  { code: 'es', name: 'Spanish (Español)' },
  { code: 'fr', name: 'French (Français)' },
  { code: 'de', name: 'German (Deutsch)' },
  { code: 'zh-CN', name: 'Chinese (Simplified)' },
  { code: 'ar', name: 'Arabic (العربية)' },
  { code: 'ru', name: 'Russian (Русский)' },
  { code: 'pt', name: 'Portuguese (Português)' },
  { code: 'ja', name: 'Japanese (日本語)' },
  { code: 'ko', name: 'Korean (한국어)' },
  { code: 'tr', name: 'Turkish (Türkçe)' },
  { code: 'it', name: 'Italian (Italiano)' },
  { code: 'nl', name: 'Dutch (Nederlands)' },
  { code: 'pl', name: 'Polish (Polski)' },
  { code: 'te', name: 'Telugu (తెలుగు)' },
  { code: 'ta', name: 'Tamil (தமிழ்)' },
  { code: 'mr', name: 'Marathi (मराठी)' },
  { code: 'bn', name: 'Bengali (বাংলা)' }
];

document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('langSearchInput');
  const dropdown = document.getElementById('langDropdown');

  if (!input || !dropdown) return;

  // Render list
  const renderList = (filter = '') => {
    dropdown.innerHTML = '';
    const term = filter.toLowerCase();
    
    const filtered = supportedLanguages.filter(lang => 
      lang.name.toLowerCase().includes(term) || lang.code.includes(term)
    );

    if (filtered.length === 0) {
      dropdown.innerHTML = '<div class="lang-item" style="color:var(--text-secondary); cursor:default;">No languages found</div>';
      return;
    }

    filtered.forEach(lang => {
      const div = document.createElement('div');
      div.className = 'lang-item';
      div.textContent = lang.name;
      div.onclick = () => selectLanguage(lang.code, lang.name);
      dropdown.appendChild(div);
    });
  };

  // Open dropdown on focus
  input.addEventListener('focus', () => {
    dropdown.style.display = 'block';
    renderList(input.value);
  });

  // Filter on input
  input.addEventListener('input', (e) => {
    dropdown.style.display = 'block';
    renderList(e.target.value);
  });

  // Hide dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!input.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.style.display = 'none';
    }
  });

  renderList();
});

function selectLanguage(code, name) {
  const input = document.getElementById('langSearchInput');
  const dropdown = document.getElementById('langDropdown');
  
  input.placeholder = name;
  input.value = '';
  dropdown.style.display = 'none';

  // Trigger Google Translate hidden select
  const gtSelect = document.querySelector('.goog-te-combo');
  if (gtSelect) {
    gtSelect.value = code;
    gtSelect.dispatchEvent(new Event('change'));
  } else {
    // If the widget hasn't fully loaded, try clicking the frame or polling
    console.warn('Google Translate widget not ready. Reloading with language code...');
    // Fallback URL parameter integration if widget fails
    window.location.hash = '#googtrans(en|' + code + ')';
    location.reload();
  }
}
