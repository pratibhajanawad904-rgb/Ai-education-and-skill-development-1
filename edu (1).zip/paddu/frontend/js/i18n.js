/* ========================================
   LearnPath / eduspark — Translation Dictionary (i18n)
   ======================================== */

// 1. Define Language Translations
const translations = {
  en: {
    nav_home: "Home",
    nav_path: "My Path",
    nav_assessments: "Assessments",
    nav_dashboard: "Dashboard",
    nav_career: "Career Ideas",
    logout: "Log out",
    login_welcome: "Welcome to eduspark",
    login_desc: "Your personal career-focused learning companion.",
    get_started: "Get Started →",
    welcome_banner: "Good afternoon,",
    dashboard_title: "Progress Dashboard"
  },
  hi: {
    nav_home: "मुख्य पृष्ठ (Home)",
    nav_path: "मेरा रास्ता (My Path)",
    nav_assessments: "मूल्यांकन (Assessments)",
    nav_dashboard: "डैशबोर्ड (Dashboard)",
    nav_career: "करियर (Career)",
    logout: "लॉग आउट",
    login_welcome: "Eduspark में आपका स्वागत है",
    login_desc: "आपका व्यक्तिगत करियर सीखने का साथी।",
    get_started: "शुरू करें →",
    welcome_banner: "नमस्कार,",
    dashboard_title: "प्रगति डैशबोर्ड"
  },
  es: {
    nav_home: "Inicio",
    nav_path: "Mi Camino",
    nav_assessments: "Evaluaciones",
    nav_dashboard: "Tablero",
    nav_career: "Ideas de Carrera",
    logout: "Cerrar sesión",
    login_welcome: "Bienvenido a eduspark",
    login_desc: "Tu compañero personal de aprendizaje para tu carrera.",
    get_started: "Empezar →",
    welcome_banner: "Buenas tardes,",
    dashboard_title: "Tablero de Progreso"
  }
};

// 2. Language Switcher Logic
document.addEventListener('DOMContentLoaded', () => {
  // Load saved language or default to English
  const savedLang = localStorage.getItem('eduspark_lang') || 'en';
  
  // Set dropdown to current language if it exists
  const langSelect = document.getElementById('langSelector');
  if (langSelect) {
    langSelect.value = savedLang;
    langSelect.addEventListener('change', (e) => {
      setLanguage(e.target.value);
    });
  }

  // Apply initially
  setLanguage(savedLang);
});

function setLanguage(langCode) {
  // Save preference
  localStorage.setItem('eduspark_lang', langCode);
  
  // Get translation dictionary for selected language
  const dict = translations[langCode] || translations['en'];

  // Find all elements with a data-i18n attribute
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (dict[key]) {
      // If it's an input, change the placeholder. Otherwise, change innerText
      if (el.tagName === 'INPUT' && el.type !== 'button' && el.type !== 'submit') {
        el.placeholder = dict[key];
      } else {
        // Find existing non-text elements (like icons) so we don't overwrite them
        // For strict simplicity, just setting textContent. If it has HTML, you might use innerHTML.
        el.textContent = dict[key];
      }
    }
  });

  // Optional: Update HTML lang attribute for screen readers
  document.documentElement.lang = langCode;
}
