/* ========================================
   LearnPath — Smart Skill Assessment
   Quiz, Coding Challenge, and Aptitude tabs
   ======================================== */

// ──── Assessment Topics Data ────
const assessmentData = {
  webdev: {
    quiz: {
      easy: [
        { id: 'wd1', question: 'What does HTML stand for?', options: ['Hyper Text Markup Language', 'High Tech Modern Language', 'Hyper Transfer Main Language', 'Home Tool Markup Language'], correct: 0 },
        { id: 'wd2', question: 'Which CSS property is used to change the text color?', options: ['text-color', 'color', 'font-color', 'fg-color'], correct: 1 },
        { id: 'wd3', question: 'What is the correct way to link an external JS file?', options: ['<link src="script.js">', '<script href="script.js">', '<script src="script.js">', '<js src="script.js">'], correct: 2 },
        { id: 'wd4', question: 'Which HTML element is used for the largest heading?', options: ['<heading>', '<h6>', '<h1>', '<h0>'], correct: 2 },
        { id: 'wd5', question: 'How do you create a function in JavaScript?', options: ['function myFunction()', 'function:myFunction()', 'function = myFunction()', 'new function()'], correct: 0 },
        { id: 'wd6', question: 'Which tag is used to create a hyperlink?', options: ['<link>', '<a>', '<href>', '<url>'], correct: 1 },
        { id: 'wd7', question: 'Which CSS property controls the text size?', options: ['font-style', 'text-size', 'font-size', 'text-style'], correct: 2 },
        { id: 'wd8', question: 'Inside which HTML element do we put JavaScript?', options: ['<scripting>', '<js>', '<script>', '<javascript>'], correct: 2 },
        { id: 'wd9', question: 'Which HTML attribute is used to define inline styles?', options: ['class', 'style', 'font', 'styles'], correct: 1 },
        { id: 'wd10', question: 'How do you write "Hello World" in an alert box?', options: ['msg("Hello World");', 'alertBox("Hello World");', 'alert("Hello World");', 'msgBox("Hello World");'], correct: 2 },
        { id: 'wd11', question: 'What is the correct HTML for adding a background color?', options: ['<body bg="yellow">', '<body style="background-color:yellow;">', '<background>yellow</background>', '<body color="yellow">'], correct: 1 },
        { id: 'wd12', question: 'Which HTML element is used to specify a footer?', options: ['<section>', '<bottom>', '<footer>', '<aside>'], correct: 2 }
      ],
      hard: [
        { id: 'wd1h', question: 'What is the Virtual DOM in React?', options: ['A direct copy of the HTML', 'An in-memory representation of the real DOM', 'A type of database', 'A CSS framework feature'], correct: 1 },
        { id: 'wd2h', question: 'In JS, what is the result of typeof NaN?', options: ['"number"', '"undefined"', '"null"', '"NaN"'], correct: 0 },
        { id: 'wd3h', question: 'What is a "closure" in JavaScript?', options: ['A way to close a tab', 'A function with access to its lexical scope', 'A method to end a loop', 'A secure data storage'], correct: 1 },
        { id: 'wd4h', question: 'Which hook is used to handle side effects in React?', options: ['useState', 'useContext', 'useEffect', 'useReducer'], correct: 2 },
        { id: 'wd5h', question: 'What does "use strict" do at the top of a JS file?', options: ['Enforces stricter parsing and error handling', 'Speeds up execution', 'Minifies the code', 'Encrypts the file'], correct: 0 },
        { id: 'wd6h', question: 'What is event bubbling?', options: ['Event triggers at the source then travels up', 'Event triggers at the root then travels down', 'Events making bubbles', 'A way to stop performance leaks'], correct: 0 },
        { id: 'wd7h', question: 'Which of the following describes "hoisting" in JS?', options: ['Code optimization', 'Variable declarations are moved to top of scope', 'Uploading files', 'A type of loop'], correct: 1 },
        { id: 'wd8h', question: 'What is a Promise in JavaScript?', options: ['A guarantee that code will run', 'A value that may be available now, later, or never', 'A secure variable', 'A type of callback'], correct: 1 },
        { id: 'wd9h', question: 'What does CSS "box-sizing: border-box" do?', options: ['Adds border size to width', 'Keeps padding/border inside the defined width', 'Floats the box', 'Makes the box invisible'], correct: 1 },
        { id: 'wd10h', question: 'Which algorithm does React use for DOM diffing?', options: ['Binary Search', 'Dijkstra', 'Heuristic O(n)', 'Quick Sort'], correct: 2 },
        { id: 'wd11h', question: 'What is the purpose of the key prop in React lists?', options: ['To secure the data', 'To help React identify which items have changed', 'To style the items', 'To link to a database'], correct: 1 },
        { id: 'wd12h', question: 'In CSS Grid, what does "fr" stand for?', options: ['Fractional unit', 'Free space', 'Frequency', 'Frame'], correct: 0 }
      ]
    },
    coding: {
      task: 'Write a JavaScript function that reverses a given string.',
      hint: 'Try using .split("").reverse().join("")',
      validation: ['reverse', 'split', 'join', 'function'],
      starter: 'function reverse(str) {\n  // Write code here\n}'
    }
  },
  datascience: {
    quiz: {
      easy: [
        { id: 'ds1', question: 'Which Python library is primarily used for data manipulation and analysis?', options: ['Numpy', 'Pandas', 'Matplotlib', 'Scikit-learn'], correct: 1 },
        { id: 'ds2', question: 'What does CSV stand for?', options: ['Common System Values', 'Comma Separated Values', 'Computer Software Version', 'Central Storage Volume'], correct: 1 },
        { id: 'ds3', question: 'Which function is used to read a CSV file in Pandas?', options: ['read_file()', 'read_csv()', 'open_csv()', 'load_data()'], correct: 1 },
        { id: 'ds4', question: 'What is the main data structure in NumPy?', options: ['List', 'DataFrame', 'ndarray', 'Dictionary'], correct: 2 },
        { id: 'ds5', question: 'Which library is best for creating static plots in Python?', options: ['Matplotlib', 'TensorFlow', 'PyTorch', 'BeautifulSoup'], correct: 0 },
        { id: 'ds6', question: 'How do you check the first 5 rows of a Pandas DataFrame?', options: ['df.first()', 'df.show(5)', 'df.head()', 'df.top(5)'], correct: 2 },
        { id: 'ds7', question: 'In Python, which list method appends an element at the end?', options: ['add()', 'insert()', 'append()', 'push()'], correct: 2 },
        { id: 'ds8', question: 'What is the command to install a library via pip?', options: ['pip download', 'pip install', 'get install', 'pip link'], correct: 1 },
        { id: 'ds9', question: 'Which data type is used for True/False values in Python?', options: ['String', 'Integer', 'Boolean', 'Float'], correct: 2 },
        { id: 'ds10', question: 'Which of the following is a Python dictionary?', options: ['[1, 2]', '(1, 2)', '{"key": "value"}', '{1, 2}'], correct: 2 },
        { id: 'ds11', question: 'Which library is used for Sci-calc in Python?', options: ['SciPy', 'OpenCV', 'Django', 'Flask'], correct: 0 },
        { id: 'ds12', question: 'What does the "range()" function return?', options: ['A list', 'A sequence of numbers', 'A random number', 'An array'], correct: 1 }
      ],
      hard: [
        { id: 'ds1h', question: 'What is Overfitting in Machine Learning?', options: ['Model is too simple', 'Model performs well on training but poorly on test data', 'Model is too fast', 'Model has too many features'], correct: 1 },
        { id: 'ds2h', question: 'What is the purpose of "p-value" in statistics?', options: ['To measure population size', 'To determine statistical significance', 'To calculate the mean', 'To find the peak value'], correct: 1 },
        { id: 'ds3h', question: 'Which algorithm is typically used for unsupervised clustering?', options: ['Linear Regression', 'SVM', 'K-Means', 'Random Forest'], correct: 2 },
        { id: 'ds4h', question: 'In Pandas, what does .iloc do?', options: ['Selects rows by label', 'Selects rows by integer index', 'Filters rows by value', 'Sorts the data'], correct: 1 },
        { id: 'ds5h', question: 'What is the Central Limit Theorem?', options: ['Rule for limit calculation', 'The distribution of sample means approaches normal', 'A way to limit data size', 'A sorting algorithm'], correct: 1 },
        { id: 'ds6h', question: 'What is the difference between L1 and L2 regularization?', options: ['L1 adds absolute value, L2 adds square', 'L1 is faster', 'L2 removes features', 'None'], correct: 0 },
        { id: 'ds7h', question: 'What does ROC curve stand for?', options: ['Rate of Change', 'Receiver Operating Characteristic', 'Result of Correlation', 'Ratio of Coefficients'], correct: 1 },
        { id: 'ds8h', question: 'What is Eigenvalue in data science context?', options: ['A type of variable', 'A scalar multiplier in linear transformation', 'A database key', 'A plot label'], correct: 1 },
        { id: 'ds9h', question: 'Which method handles missing values by filling them?', options: ['dropna()', 'fillna()', 'mask()', 'replace()'], correct: 1 },
        { id: 'ds10h', question: 'In Sklearn, which object is used to split data into train/test sets?', options: ['Splitter', 'train_test_split', 'model_selection', 'DataManager'], correct: 1 },
        { id: 'ds11h', question: 'What is a "Resample" in time series analysis?', options: ['Changing frequency', 'Deleting data', 'Copying data', 'A type of plot'], correct: 0 },
        { id: 'ds12h', question: 'What does "StandardScaler" do?', options: ['Scales data to mean 0 and variance 1', 'Formats strings', 'Calculates averages', 'Sorts the data'], correct: 0 }
      ]
    },
    coding: {
      task: 'Write a Python-like function that calculates the mean of an array of numbers.',
      hint: 'Sum the elements and divide by the length.',
      validation: ['sum', 'length', 'divide', 'return'],
      starter: 'def calculate_mean(arr):\n    # Write logic here\n    pass'
    }
  },
  aiml: {
    quiz: {
      easy: [
        { id: 'ai1', question: 'What is the goal of Supervised Learning?', options: ['To find patterns in unlabeled data', 'To map inputs to outputs based on labeled pairs', 'To play games', 'To generate images'], correct: 1 },
        { id: 'ai2', question: 'Which activation function is most common in hidden layers of Deep Networks?', options: ['Sigmoid', 'Softmax', 'ReLU', 'Linear'], correct: 2 },
        { id: 'ai3', question: 'What does NLP stand for?', options: ['Next Level Physics', 'Natural Logic Processor', 'Natural Language Processing', 'New Linear Programming'], correct: 2 },
        { id: 'ai4', question: 'Which company developed TensorFlow?', options: ['Facebook', 'Google', 'Microsoft', 'OpenAI'], correct: 1 },
        { id: 'ai5', question: 'What is a Neuron in a Neural Network?', options: ['A single variable', 'A processing unit that applies weights and bias', 'A type of CPU', 'A memory storage block'], correct: 1 },
        { id: 'ai6', question: 'What is an "Epoch" in AI training?', options: ['One minute of training', 'One pass through the entire training dataset', 'A type of model', 'The creator of AI'], correct: 1 },
        { id: 'ai7', question: 'Which type of neural network is best for image processing?', options: ['RNN', 'CNN', 'LSTM', 'GAN'], correct: 1 },
        { id: 'ai8', question: 'What does "AI" stand for?', options: ['Advanced Info', 'Artificial Intelligence', 'Auto Interface', 'Actual Intel'], correct: 1 },
        { id: 'ai9', question: 'In AI, what is "Labeling"?', options: ['Naming variables', 'Tagging data with correct answers', 'Printing stickers', 'Describing the model'], correct: 1 },
        { id: 'ai10', question: 'Which language is most used for AI development?', options: ['Java', 'C++', 'Python', 'PHP'], correct: 2 },
        { id: 'ai11', question: 'What is "Reinforcement Learning"?', options: ['Learning by repetition', 'Learning by reward and punishment', 'Helping others learn', 'Using hardware accelerators'], correct: 1 },
        { id: 'ai12', question: 'What is a "Chatbot"?', options: ['A robot that walks', 'An AI program that interacts via text/speech', 'A social media app', 'A fast browser'], correct: 1 }
      ],
      hard: [
        { id: 'ai1h', question: 'What is Backpropagation?', options: ['A way to store data', 'An algorithm for updating weights in a neural network', 'A type of clustering', 'A hardware optimization'], correct: 1 },
        { id: 'ai2h', question: 'What is a "Transformer" in AI context?', options: ['A heavy electrical device', 'A model architecture using attention mechanisms', 'A tool to convert files', 'A robot animation library'], correct: 1 },
        { id: 'ai3h', question: 'What is the "Vanishing Gradient" problem?', options: ['Memory leak', 'Gradients becoming very close to zero during training', 'Model being deleted', 'Loss function not decreasing'], correct: 1 },
        { id: 'ai4h', question: 'Which metric is commonly used for evaluating image classification?', options: ['RMSE', 'F1 Score', 'Accuracy (Top-1/Top-5)', 'Precision'], correct: 2 },
        { id: 'ai5h', question: 'What is "Fine-tuning" in LLMs?', options: ['Changing volume', 'Adjusting a pre-trained model on a specific dataset', 'Deleting old data', 'Making the font smaller'], correct: 1 },
        { id: 'ai6h', question: 'What is "Dropout" in a neural network?', options: ['Quitting the course', 'Randomly ignoring neurons during training', 'Losing data', 'A type of skip connection'], correct: 1 },
        { id: 'ai7h', question: 'What does GPT stand for?', options: ['Generic Process Tool', 'Generative Pre-trained Transformer', 'Global Positioning Tech', 'General Purpose Task'], correct: 1 },
        { id: 'ai8h', question: 'What is an "Anchor Box" in object detection?', options: ['A fixed box used for prediction', 'A link to a website', 'A storage box', 'A UI element'], correct: 0 },
        { id: 'ai9h', question: 'What is the "Attention Mechanism"?', options: ['Focusing on teacher', 'Weighted relevance assigned to input parts', 'Stopping the training', 'A type of regularization'], correct: 1 },
        { id: 'ai10h', question: 'Which optimization algorithm is most popular in Deep Learning?', options: ['SGD', 'Adam', 'BFGS', 'Simplex'], correct: 1 },
        { id: 'ai11h', question: 'What is "Latent Space"?', options: ['Space between neurons', 'Compressed representation of data', 'Empty storage', 'A type of cloud service'], correct: 1 },
        { id: 'ai12h', question: 'What is a "GAN" (Generative Adversarial Network)?', options: ['A networking protocol', 'Two networks competing to generate data', 'A simple filter', 'A faster CPU'], correct: 1 }
      ]
    },
    coding: {
      task: 'Define a function that implements a simple ReLU activation (return 0 if x < 0, else x).',
      hint: 'Use a simple if-else or Math.max(0, x).',
      validation: ['max', 'if', 'return', '0'],
      starter: 'function relu(x) {\n  // Write logic here\n}'
    }
  },
  iot: {
    quiz: {
      easy: [
        { id: 'io1', question: 'What does MQTT stand for?', options: ['Message Queuing Telemetry Transport', 'Mobile Quick Text Transfer', 'Model Query Task Trace', 'Main Queue Toggle Type'], correct: 0 },
        { id: 'io2', question: 'Which protocol is commonly used for low-power IoT connectivity?', options: ['HTTP', 'FTP', 'LoRaWAN', 'SSH'], correct: 2 },
        { id: 'io3', question: 'What is a "Sensor"?', options: ['A data storage device', 'A device that detects changes in the environment', 'A power supply', 'A type of screen'], correct: 1 },
        { id: 'io4', question: 'Which device is a popular microcontroller for IoT?', options: ['Intel i9', 'ESP32', 'NVIDIA 4090', 'iPhone 15'], correct: 1 },
        { id: 'io5', question: 'What is the purpose of an "Actuator"?', options: ['To measure temp', 'To convert energy into motion/action', 'To store data', 'To connect to Wi-Fi'], correct: 1 },
        { id: 'io6', question: 'What is a "Gateway" in IoT?', options: ['A literal door', 'A device that connects local IoT units to the internet', 'A type of battery', 'A fast modem'], correct: 1 },
        { id: 'io7', question: 'Which wireless tech is best for short distance smart bulbs?', options: ['Satellite', 'Bluetooth/Zigbee', 'Fiber', 'Acoustic'], correct: 1 },
        { id: 'io8', question: 'What is "Smart Home"?', options: ['Home with books', 'Home where devices are connected and automated', 'A library', 'A school'], correct: 1 },
        { id: 'io9', question: 'Can an Arduino connect to Wi-Fi?', options: ['No, never', 'Yes, with specific modules/shields', 'Only via cable', 'Only if painted blue'], correct: 1 },
        { id: 'io10', question: 'What is "IoT" standing for?', options: ['Internet of Things', 'Interface of Tools', 'Input of Tech', 'Internal Online Tech'], correct: 0 },
        { id: 'io11', question: 'Which sensor measures moisture in soil?', options: ['LDR', 'Hygrometer', 'Thermister', 'Accelerometer'], correct: 1 },
        { id: 'io12', question: 'What power source is often used for remote sensors?', options: ['Main line', 'Solar / Battery', 'Wind turbine', 'Coal'], correct: 1 }
      ],
      hard: [
        { id: 'io1h', question: 'In the context of IoT, what is an Edge Node?', options: ['A central server', 'A device that processes data close to the source', 'A cloud database', 'A type of cable'], correct: 1 },
        { id: 'io2h', question: 'What is the difference between IPv4 and IPv6 for IoT?', options: ['IPv6 has a much larger address space', 'IPv4 is faster', 'IPv6 is only for phones', 'IPv4 is wireless'], correct: 0 },
        { id: 'io3h', question: 'What is Zigbee?', options: ['A messaging app', 'A low-power mesh network protocol', 'A fast fiber optic cable', 'A type of drone'], correct: 1 },
        { id: 'io4h', question: 'Which security standard is common for IoT Wi-Fi?', options: ['WPA3', 'HTTPS', 'FTP', 'SQL'], correct: 0 },
        { id: 'io5h', question: 'What is a "Digital Twin"?', options: ['A second robot', 'A digital replica of a physical entity/system', 'A backup of the cloud', 'A duplicate sensor'], correct: 1 },
        { id: 'io6h', question: 'What is the 6LoWPAN protocol?', options: ['A list of 6 laws', 'IPv6 over Low Power Wireless Personal Area Networks', 'A 6-bit processor', 'A slow modem'], correct: 1 },
        { id: 'io7h', question: 'Which protocol uses Pub/Sub pattern?', options: ['HTTP', 'MQTT', 'SSH', 'Telnet'], correct: 1 },
        { id: 'io8h', question: 'What is "Firmware" in IoT?', options: ['Software hardcoded into the device hardware', 'Soft metal', 'A data warehouse', 'A cloud service'], correct: 0 },
        { id: 'io9h', question: 'What is "LoRa" ?', options: ['Long Range wireless data communication', 'Low Radio', 'A type of sensor', 'A messaging platform'], correct: 0 },
        { id: 'io10h', question: 'What is the role of a "Broker" in MQTT?', options: ['Selling devices', 'A central hub that handles messages between clients', 'A web browser', 'A security wall'], correct: 1 },
        { id: 'io11h', question: 'What is "Interoperability" in IoT?', options: ['Working fast', 'Ability of different systems to communicate seamlessly', 'Measuring power', 'Data encryption'], correct: 1 },
        { id: 'io12h', question: 'Which layer of IoT architecture handles data storage?', options: ['Perception', 'Cloud / Application', 'Link Layer', 'Physical'], correct: 1 }
      ]
    },
    coding: {
      task: 'Write a logic that checks if a sensor value is above 50 and returns "ALARM", otherwise "OK".',
      hint: 'Use an if-else statement.',
      validation: ['if', '50', 'ALARM', 'OK'],
      starter: 'function checkSensor(value) {\n  // Write logic here\n}'
    }
  },
  vlsi: {
    quiz: {
      easy: [
        { id: 'vl1', question: 'What does VLSI stand for?', options: ['Very Large Scale Integration', 'Variable Level System Interface', 'Virtual Logic Silicon Industry', 'Vector Low Speed Index'], correct: 0 },
        { id: 'vl2', question: 'Which language is most used for Hardware Description?', options: ['C++', 'Verilog', 'Python', 'Java'], correct: 1 },
        { id: 'vl3', question: 'What is an "FPGA"?', options: ['Fixed Program Gate Array', 'Field Programmable Gate Array', 'Fast Logic Processor', 'Floating Point Gateway'], correct: 1 },
        { id: 'vl4', question: 'Which gate is considered a universal gate?', options: ['AND', 'OR', 'NAND', 'XOR'], correct: 2 },
        { id: 'vl5', question: 'What is the basic building block of a CMOS circuit?', options: ['Resistor', 'Inductor', 'MOSFET', 'Vacuum Tube'], correct: 2 },
        { id: 'vl6', question: 'How many transistors are in a simple NOT gate (CMOS)?', options: ['1', '2', '4', '0'], correct: 1 },
        { id: 'vl7', question: 'What is "VHDL"?', options: ['Video Language', 'VHS Tape', 'Hardware Description Language', 'Virtual Drive Language'], correct: 2 },
        { id: 'vl8', question: 'What does "ASIC" stand for?', options: ['Application Specific Integrated Circuit', 'Advanced System in Chip', 'Actual Silicon Info Center', 'All System in Core'], correct: 0 },
        { id: 'vl9', question: 'Which tool is used for circuit schematic capture?', options: ['Photoshop', 'Cadence / OrCAD', 'Excel', 'Word'], correct: 1 },
        { id: 'vl10', question: 'What is the unit of measure for IC feature sizes?', options: ['cm', 'mm', 'nm', 'm'], correct: 2 },
        { id: 'vl11', question: 'What is a "Wafer"?', options: ['A cookie', 'A thin slice of semiconductor used for ICs', 'A power supply', 'A test probe'], correct: 1 },
        { id: 'vl12', question: 'In logic, what is 1 XOR 1?', options: ['1', '2', '0', 'Error'], correct: 2 }
      ],
      hard: [
        { id: 'vl1h', question: 'What is the primary purpose of Static Timing Analysis (STA)?', options: ['To check logic functionality', 'To verify timing constraints without dynamic simulation', 'To generate layout', 'To calculate power'], correct: 1 },
        { id: 'vl2h', question: 'What is "Clock Tree Synthesis" (CTS)?', options: ['A way to grow plants', 'The process of distributing clock signals evenly across a chip', 'A timing analysis tool', 'A type of HDL'], correct: 1 },
        { id: 'vl3h', question: 'Which rule defines the setup time requirement?', options: ['Data must be stable after the clock edge', 'Data must arrive before the clock edge', 'Clock must be faster than data', 'Data must be inverted'], correct: 1 },
        { id: 'vl4h', question: 'What is "LVS" in physical design?', options: ['Logic vs Simulation', 'Layout vs Schematic', 'Line vs Sound', 'Link vs System'], correct: 1 },
        { id: 'vl5h', question: 'What is the purpose of "Standard Cells" in VLSI?', options: ['Standardized battery units', 'Pre-designed logic blocks for automated layout', 'Memory units for storage', 'Testing units'], correct: 1 },
        { id: 'vl6h', question: 'Which tool handles "Place and Route"?', options: ['Vivado / Innovus', 'Visual Studio', 'Eclipse', 'Gedit'], correct: 0 },
        { id: 'vl7h', question: 'What is "DOPING" in semiconductor engineering?', options: ['A sports scandal', 'Adding impurities to change conductivity', 'Measuring heat', 'Cleaning the chip'], correct: 1 },
        { id: 'vl8h', question: 'What is "Parasitic Extraction"?', options: ['Removing bugs', 'Calculating unwanted resistance/capacitance in layout', 'Cleaning silicon', 'Testing power'], correct: 1 },
        { id: 'vl9h', question: 'What does the "DRC" check verify?', options: ['Design Rule Consistency', 'Design Rule Check for geometric constraints', 'Data Read Circle', 'Drive Route Center'], correct: 1 },
        { id: 'vl10h', question: 'Which layer is used for interconnects in ICs?', options: ['Substrate', 'Polysilicon', 'Metal layers', 'Oxide'], correct: 2 },
        { id: 'vl11h', question: 'What is "Electromigration"?', options: ['Moving electrons to moon', 'Material transport caused by current flow', 'A type of battery', 'A fast modem'], correct: 1 },
        { id: 'vl12h', question: 'What is "Power Integrity" (PI)?', options: ['Being honest about power', 'Ensuring stable voltage throughout the chip', 'Power saving', 'Fast charging'], correct: 1 }
      ]
    },
    coding: {
      task: 'Write a Verilog-like logic for a 2-input AND gate.',
      hint: 'assign y = a & b;',
      validation: ['assign', 'and', '&', ';'],
      starter: 'module and_gate(input a, input b, output y);\n  // Write assignment here\nendmodule'
    }
  },
  embedded: {
    quiz: {
      easy: [
        { id: 'em1', question: 'Which keyword is used in C to define a persistent variable in a function?', options: ['extern', 'auto', 'static', 'register'], correct: 2 },
        { id: 'em2', question: 'What is an RTOS?', options: ['Real-Time Operating System', 'Remote Terminal Online Service', 'Read-Time Only Storage', 'Random Type Output Selector'], correct: 0 },
        { id: 'em3', question: 'Which register is used to point to the next instruction?', options: ['Accumulator', 'Stack Pointer', 'Program Counter', 'Data Register'], correct: 2 },
        { id: 'em4', question: 'What is a "Baud Rate"?', options: ['Power consumption', 'The speed of serial communication', 'Memory size', 'Processor clock speed'], correct: 1 },
        { id: 'em5', question: 'How is a bitwise AND operation written in C?', options: ['&&', '&', '|', '^'], correct: 1 },
        { id: 'em6', question: 'What is a "Compiler"?', options: ['A music player', 'A tool that converts code to machine language', 'A browser', 'A text editor'], correct: 1 },
        { id: 'em7', question: 'Which protocol uses only 2 wires for communication?', options: ['SPI', 'I2C', 'Parallel', 'USB'], correct: 1 },
        { id: 'em8', question: 'What does "GPIO" stand for?', options: ['General Purpose I/O', 'Global Power Interface', 'Ground Power Input', 'Grid Point Output'], correct: 0 },
        { id: 'em9', question: 'In C, what does "int *ptr" declare?', options: ['A regular integer', 'A pointer to an integer', 'A list of integers', 'An error'], correct: 1 },
        { id: 'em10', question: 'What is "EEPROM"?', options: ['Flash drive', 'Electrically Erasable Programmable Read-Only Memory', 'A slow RAM', 'A type of sensor'], correct: 1 },
        { id: 'em11', question: 'What is the purpose of a "Pull-up Resistor"?', options: ['To heat up the board', 'To ensure a stable high logic level', 'To limit current to 0', 'To ground the circuit'], correct: 1 },
        { id: 'em12', question: 'Which storage is volatile?', options: ['Flash', 'ROM', 'RAM', 'SD Card'], correct: 2 }
      ],
      hard: [
        { id: 'em1h', question: 'What is an Interrupt Service Routine (ISR)?', options: ['A loop that waits for input', 'A function called by hardware when an interrupt occurs', 'A library for math', 'A debugger tool'], correct: 1 },
        { id: 'em2h', question: 'What is "Priority Inversion"?', options: ['A high-priority task waiting for a low-priority task', 'A task reversal', 'A bug in the compiler', 'A hardware failure'], correct: 0 },
        { id: 'em3h', question: 'What is a "Watchdog Timer"?', options: ['A timer for pets', 'A hardware timer that resets the system if it hangs', 'A clock for the screen', 'A power saving mode'], correct: 1 },
        { id: 'em4h', question: 'In C, what is a "volatile" variable?', options: ['A variable that changes frequently', 'A variable that can be changed by external hardware/interrupts', 'A variable that is stored in RAM', 'A temporary variable'], correct: 1 },
        { id: 'em5h', question: 'What is the difference between a Microprocessor and a Microcontroller?', options: ['None', 'Microcontroller has integrated memory and peripherals', 'Microprocessor is smaller', 'Microcontroller is faster'], correct: 1 },
        { id: 'em6h', question: 'What is "Little Endian" memory storage?', options: ['Big data', 'Least significant byte stored at lowest address', 'Most significant byte first', 'A type of file'], correct: 1 },
        { id: 'em7h', question: 'What is "DMA" (Direct Memory Access)?', options: ['Fast storage', 'Hardware allowing peripherals to access RAM without CPU', 'A type of pointer', 'A cache memory'], correct: 1 },
        { id: 'em8h', question: 'Which scheduler algorithm is common in RTOS?', options: ['LIFO', 'Preemptive Priority Based', 'Random', 'Sequential'], correct: 1 },
        { id: 'em9h', question: 'What is the "Context Switch"?', options: ['Changing page', 'Saving process state to switch to another task', 'Rebooting', 'A type of register'], correct: 1 },
        { id: 'em10h', question: 'What is "JTAG"?', options: ['A file tag', 'Standard for testing and debugging ICs', 'A fast modem', 'A type of code'], correct: 1 },
        { id: 'em11h', question: 'What happens in a "Stack Overflow"?', options: ['Too many variables in heap', 'Stack pointer exceeds allocated memory', 'Website crash', 'Memory leak'], correct: 1 },
        { id: 'em12h', question: 'What is "Memory Mapping"?', options: ['Drawing a map of RAM', 'Assigning addresses to peripherals and memory', 'A type of cache', 'Backing up data'], correct: 1 }
      ]
    },
    coding: {
      task: 'Write a C snippet to toggle a bit in a register (using bitwise XOR).',
      hint: 'Use REG ^= (1 << bit);',
      validation: ['^=', '<<', '1', ';'],
      starter: 'void toggle_bit(int *reg, int bit) {\n  // Write XOR logic here\n}'
    }
  }
};

const aptitudeQuestions = [
  { id: 'a1', question: 'If 5 machines can produce 5 items in 5 minutes, how many machines are needed to produce 100 items in 100 minutes?', options: ['100', '5', '20', '50'], correct: 1 },
  { id: 'a2', question: 'What comes next in the series: 2, 6, 12, 20, __?', options: ['28', '30', '32', '26'], correct: 1 },
  { id: 'a3', question: 'A program runs in O(n²) time. If input doubles, the running time approximately:', options: ['Doubles', 'Triples', 'Quadruples', 'Stays the same'], correct: 2 },
  { id: 'a4', question: 'If all "Zeps" are "Mops" and some "Mops" are "Lops", which is definitely true?', options: ['All Zeps are Lops', 'Some Zeps are Lops', 'No Zep is a Lop', 'Cannot be determined'], correct: 3 },
  { id: 'a5', question: 'A train 120m long passes a pole in 6 seconds. What is its speed?', options: ['20 m/s', '72 km/h', 'Both A and B', 'None of these'], correct: 2 },
  { id: 'a6', question: 'Look at this series: 7, 10, 8, 11, 9, 12, ... What number should come next?', options: ['7', '10', '12', '13'], correct: 1 },
  { id: 'a7', question: 'Which word does NOT belong with the others?', options: ['index', 'glossary', 'chapter', 'book'], correct: 3 }
];

// ──── Globals ────
let currentTopic = 'webdev';
let currentDifficulty = 'easy';
let quizAnswers = {};
let aptitudeAnswers = {};
let randomizedQuiz = [];

// ──── Helpers ────
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function capitalizeStr(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

function getTopicFromQuestion(question) {
  const topics = {
    'html': 'Web Structure',
    'css': 'Styling & Layout',
    'js': 'Frontend Logic',
    'python': 'Data Scripting',
    'pandas': 'Data Analysis',
    'mqtt': 'IoT Protocols',
    'verilog': 'Hardware Design',
    'rtos': 'System Concepts',
    'interrupt': 'Firmware Logic',
    'logic': 'Logical Reasoning'
  };
  
  for (const [key, val] of Object.entries(topics)) {
    if (question.toLowerCase().includes(key)) return val;
  }
  return 'Core Subject Knowledge';
}

// ──── Initialize ────
function initAssessments() {
  const data = getAppData();
  if (data && data.goal) {
    currentTopic = data.goal;
    const topicSelect = document.getElementById('assessmentTopic');
    if (topicSelect) topicSelect.value = currentTopic;
  }
  
  refreshAssessments();
}

function refreshAssessments() {
  retakeQuiz();
  renderAptitude();
  updateCodingChallenge();
}

function changeAssessmentTopic() {
  currentTopic = document.getElementById('assessmentTopic').value;
  refreshAssessments();
}

// ──── Tab Switching ────
function switchAssessmentTab(tab) {
  const tabs = document.querySelectorAll('.assessment-tab');
  const contents = document.querySelectorAll('.assessment-content');
  
  tabs.forEach(t => t.classList.remove('active'));
  contents.forEach(c => c.classList.remove('active'));

  const activeTab = document.querySelector(`.assessment-tab[data-tab="${tab}"]`);
  if (activeTab) activeTab.classList.add('active');
  
  const content = document.getElementById(`tab-${tab}`);
  if (content) content.classList.add('active');

  if (tab === 'certificate') {
    checkAndAllowCertificate();
  }
}

// ──── AI Quiz Agent Logic ────
let aiQuizState = {
  active: false,
  questions: [],
  currentIndex: 0,
  score: 0,
  answers: [],
  strengths: [],
  weaknesses: []
};

function startAIQuiz() {
  const container = document.getElementById('aiQuizChat');
  if (!container) return;

  // Initialize state
  const allQuestions = assessmentData[currentTopic].quiz[currentDifficulty];
  const pool = [...allQuestions];
  shuffleArray(pool);
  
  aiQuizState = {
    active: true,
    questions: pool.slice(0, 10),
    currentIndex: 0,
    score: 0,
    answers: [],
    strengths: [],
    weaknesses: []
  };

  // Switch to chat mode
  container.innerHTML = `
    <div class="ai-chat-messages" id="aiMessages"></div>
    <div class="ai-chat-footer">
      <div class="progress-stepper" id="aiProgress"></div>
      <div id="aiTyping" class="ai-typing hidden">AI is thinking...</div>
    </div>
  `;

  renderAIProgress();
  
  addChatMessage('ai', `Awesome! I'm so excited to help you test your skills in **${capitalizeStr(currentTopic)}**. I'll ask you 10 questions. Don't worry if you get some wrong—it's all part of the learning journey!`);
  
  setTimeout(() => {
    askAIQuestion();
  }, 1500);
}

function renderAIProgress() {
  const stepper = document.getElementById('aiProgress');
  if (!stepper) return;
  stepper.innerHTML = '';
  for (let i = 0; i < 10; i++) {
    const dot = document.createElement('div');
    dot.className = `step-dot ${i < aiQuizState.currentIndex ? 'completed' : i === aiQuizState.currentIndex ? 'active' : ''}`;
    stepper.appendChild(dot);
  }
}

function addChatMessage(role, text, options = null, targetId = 'aiMessages') {
  const msgs = document.getElementById(targetId);
  if (!msgs) return;

  const msgDiv = document.createElement('div');
  msgDiv.className = `message ${role}`;
  msgDiv.innerHTML = text;

  if (options && Array.isArray(options)) {
    const optContainer = document.createElement('div');
    optContainer.className = 'ai-options-container';
    options.forEach((opt, idx) => {
      const btn = document.createElement('button');
      btn.className = 'ai-opt-btn';
      btn.textContent = opt;
      btn.onclick = () => handleAIAnswer(idx, opt);
      optContainer.appendChild(btn);
    });
    msgDiv.appendChild(optContainer);
  }

  msgs.appendChild(msgDiv);
  msgs.scrollTop = msgs.scrollHeight;
}

function askAIQuestion() {
  if (aiQuizState.currentIndex >= 10) {
    finishAIQuiz();
    return;
  }

  const q = aiQuizState.questions[aiQuizState.currentIndex];
  
  // Randomize options for this session
  const correctText = q.options[q.correct];
  const shuffledOptions = shuffleArray([...q.options]);
  const newCorrectIdx = shuffledOptions.indexOf(correctText);
  
  aiQuizState.currentCorrectIdx = newCorrectIdx;
  aiQuizState.currentCorrectText = correctText;

  toggleAITyping(true);
  
  setTimeout(() => {
    toggleAITyping(false);
    const qPrefix = aiQuizState.currentIndex === 0 ? "First question! " : 
                    aiQuizState.currentIndex === 4 ? "You're halfway there! Keep it up. " :
                    aiQuizState.currentIndex === 9 ? "Last one! You've done great so far. " : "";
                    
    addChatMessage('ai', `<strong>Q${aiQuizState.currentIndex + 1}:</strong> ${qPrefix}${q.question}`, shuffledOptions);
    renderAIProgress();
  }, 800);
}

function handleAIAnswer(idx, text) {
  // Disable options in the last message
  const lastMsg = document.querySelector('.message.ai:last-child');
  if (lastMsg) {
    const btns = lastMsg.querySelectorAll('.ai-opt-btn');
    btns.forEach(b => b.disabled = true);
  }

  addChatMessage('user', text);
  
  const q = aiQuizState.questions[aiQuizState.currentIndex];
  const isCorrect = idx === aiQuizState.currentCorrectIdx;
  
  if (isCorrect) {
    aiQuizState.score += 10;
    aiQuizState.strengths.push(getTopicFromQuestion(q.question));
  } else {
    aiQuizState.weaknesses.push(getTopicFromQuestion(q.question));
  }

  aiQuizState.currentIndex++;
  
  toggleAITyping(true);
  
  setTimeout(() => {
    toggleAITyping(false);
    const feedback = getMotivationalFeedback(isCorrect);
    addChatMessage('ai', feedback);
    
    setTimeout(() => {
      askAIQuestion();
    }, 1200);
  }, 800);
}

function getMotivationalFeedback(isCorrect) {
  const correctMsgs = [
    "Spot on! You really know your stuff.",
    "Excellent! Your hard work is paying off.",
    "That's correct! I'm impressed by your knowledge.",
    "Bullseye! You're crushing this assessment.",
    "Correct! You've got a sharp mind for this."
  ];
  
  const wrongMsgs = [
    `Not quite, but that was a tricky one! The correct answer was <strong>${aiQuizState.currentCorrectText}</strong>. Keep going, you're learning!`,
    `Close! But it's actually <strong>${aiQuizState.currentCorrectText}</strong>. Don't let it stop you, every mistake is a step forward!`,
    `That's a tough one! The answer is <strong>${aiQuizState.currentCorrectText}</strong>. You're doing great, keep your head up!`,
    `Good try! It happens to the best of us. It's <strong>${aiQuizState.currentCorrectText}</strong>. Stay focused, you've got this!`
  ];

  return isCorrect ? 
    correctMsgs[Math.floor(Math.random() * correctMsgs.length)] : 
    wrongMsgs[Math.floor(Math.random() * wrongMsgs.length)];
}

function toggleAITyping(show, targetId = 'aiTyping') {
  const typing = document.getElementById(targetId);
  if (typing) {
    if (show) typing.classList.remove('hidden');
    else typing.classList.add('hidden');
  }
}

function finishAIQuiz() {
  const score = aiQuizState.score;
  const correct = score / 10;
  const total = 10;
  
  addChatMessage('ai', `Whew! We're all done. You should be proud of yourself for completing the assessment! I'm calculating your results now...`);
  
  setTimeout(() => {
    const data = getAppData();
    data.quizScores.push({ score, date: new Date().toISOString(), difficulty: currentDifficulty, topic: currentTopic });
    data.avgScore = Math.round(data.quizScores.reduce((sum, s) => sum + s.score, 0) / (data.quizScores.length || 1));
    saveAppData(data);

    showQuizResults(score, correct, total, aiQuizState.strengths, aiQuizState.weaknesses);
    
    if (score < 50 && currentDifficulty === 'hard') {
      currentDifficulty = 'easy';
    } else if (score >= 80 && currentDifficulty === 'easy') {
      currentDifficulty = 'hard';
    }
  }, 1500);
}

function showQuizResults(score, correct, total, strengths, weaknesses) {
  const panel = document.getElementById('quizResults');
  if (!panel) return;
  panel.classList.remove('hidden');

  const uniqueStrengths = [...new Set(strengths)];
  const uniqueWeaknesses = [...new Set(weaknesses)];

  let strengthsHTML = uniqueStrengths.length > 0
    ? uniqueStrengths.map(s => `<div class="strength-item"><span>${s}</span><div class="strength-bar"><div class="strength-bar-fill high" style="width:${70 + Math.random() * 25}%"></div></div></div>`).join('')
    : '<p class="text-muted text-small">Keep practicing to build your strengths!</p>';

  let weaknessesHTML = uniqueWeaknesses.length > 0
    ? uniqueWeaknesses.map(w => `<div class="strength-item"><span>${w}</span><div class="strength-bar"><div class="strength-bar-fill low" style="width:${20 + Math.random() * 30}%"></div></div></div>`).join('')
    : '<p class="text-muted text-small">Great job — no weak areas detected!</p>';

  panel.innerHTML = `
    <h3>Your Results (${capitalizeStr(currentTopic)})</h3>
    <div style="display:flex; gap:20px; margin-bottom:20px; flex-wrap:wrap;">
      <div class="stat-card" style="flex:1; min-width:120px;">
        <div class="stat-value" style="color:${score >= 70 ? 'var(--accent)' : score >= 50 ? 'var(--warning)' : 'var(--danger)'};">${score}%</div>
        <div class="stat-label">Score</div>
      </div>
      <div class="stat-card" style="flex:1; min-width:120px;">
        <div class="stat-value">${correct}/${total}</div>
        <div class="stat-label">Correct Answers</div>
      </div>
    </div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
      <div>
        <h4 style="font-size:0.92rem; font-weight:600; margin-bottom:10px; color:var(--accent);">Strengths</h4>
        ${strengthsHTML}
      </div>
      <div>
        <h4 style="font-size:0.92rem; font-weight:600; margin-bottom:10px; color:var(--danger);">Needs Practice</h4>
        ${weaknessesHTML}
      </div>
    </div>
    <button class="btn-secondary btn-sm mt-16" onclick="retakeQuiz()">Restart AI Assessment</button>`;
  
  panel.scrollIntoView({ behavior: 'smooth' });
}

function retakeQuiz() {
  const chat = document.getElementById('aiQuizChat');
  if (chat) {
    chat.innerHTML = `
      <div class="ai-chat-welcome">
        <div class="ai-avatar-large"><i data-lucide="bot" style="width: 48px; height: 48px; color: var(--primary);"></i></div>
        <h3>Ready for another round?</h3>
        <p>I've got a fresh set of questions ready for you. Let's sharpen those skills!</p>
        <button class="btn-primary" onclick="startAIQuiz()" id="startQuizBtn">Start New Assessment</button>
      </div>
    `;
  }
  const panel = document.getElementById('aptitudeResults');
  if (panel) panel.classList.add('hidden');
}

// ──── Mock Interview Logic (Voice Based) ────
let mockState = {
  currentIndex: 0,
  questions: [
    { id: 'intro', text: "Welcome to the Eduspark Mock Interview! I'm so happy to be here with you. To start off, could you please introduce yourself? I'd love to know a bit about you!" },
    { id: 'goal', text: "That's wonderful! It's great to know you better. Now, tell me, what are your primary career goals? What drives you every day?" },
    { id: 'strengths', text: "I love that ambition! You've got a great vision. Speaking of which, what would you say are your biggest strengths? What are you most proud of in your skill set?" },
    { id: 'weaknesses', text: "Honesty is such a powerful trait! Thank you for sharing. We all have areas to grow. What are some weaknesses you're currently working on improving?" },
    { id: 'interests', text: "That's a very proactive approach! Finally, do you have any specific ideas or interests you'd like to pursue in your career? What topics really get you excited?" }
  ],
  responses: {},
  isListening: false
};

function startMockInterview() {
  const container = document.getElementById('mockInterviewChat');
  if (!container) return;

  mockState.currentIndex = 0;
  mockState.responses = {};

  container.innerHTML = `
    <div class="ai-chat-messages" id="mockMessages"></div>
    <div class="ai-chat-footer">
      <div id="mockTyping" class="ai-typing hidden">AI is speaking...</div>
      <div class="mic-btn-container">
        <button class="btn-mic" id="micBtn" onclick="toggleMic()">
          <i data-lucide="mic"></i>
        </button>
        <div id="micStatus" class="voice-status">Click the mic to speak</div>
        <div id="visualizer" class="voice-visualizer hidden">
          <div class="voice-bar"></div><div class="voice-bar"></div><div class="voice-bar"></div><div class="voice-bar"></div><div class="voice-bar"></div>
        </div>
      </div>
    </div>
  `;
  
  if (typeof lucide !== 'undefined') lucide.createIcons();

  addChatMessage('ai', "Hello! I'm your AI Interviewer. I'll be guiding you through a friendly practice session. Please make sure your speakers are on!", null, 'mockMessages');
  
  setTimeout(() => {
    askMockQuestion();
  }, 2000);
}

function askMockQuestion() {
  if (mockState.currentIndex >= mockState.questions.length) {
    finishMockInterview();
    return;
  }

  const q = mockState.questions[mockState.currentIndex];
  addChatMessage('ai', q.text, null, 'mockMessages');
  speakText(q.text);
}

function toggleMic() {
  if (mockState.isListening) {
    if (mockState.recognition) mockState.recognition.stop();
    stopListening();
  } else {
    startListening();
  }
}

function startListening() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    alert("Voice recognition is not supported in this browser. Please try Chrome.");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = true;
  recognition.continuous = true;
  mockState.recognition = recognition;
  
  let finalTranscript = '';

  mockState.isListening = true;
  const micBtn = document.getElementById('micBtn');
  const micStatus = document.getElementById('micStatus');
  const visualizer = document.getElementById('visualizer');

  micBtn.classList.add('listening');
  micStatus.textContent = "Speaking... (Click to stop)";
  visualizer.classList.remove('hidden');

  recognition.onresult = (event) => {
    let interimTranscript = '';
    for (let i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        finalTranscript += event.results[i][0].transcript;
      } else {
        interimTranscript += event.results[i][0].transcript;
      }
    }
    // Optional: update UI with interim results
  };

  recognition.onend = () => {
    if (finalTranscript.trim()) {
      handleMockResponse(finalTranscript.trim());
    }
    stopListening();
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error", event.error);
    stopListening();
    if (event.error === 'no-speech') {
      addChatMessage('ai', "I didn't quite catch that. Could you please try speaking into the microphone again? I'm listening!", null, 'mockMessages');
      speakText("I didn't quite catch that. Could you please try speaking into the microphone again?");
    }
  };

  recognition.start();
}

function stopListening() {
  mockState.isListening = false;
  const micBtn = document.getElementById('micBtn');
  const micStatus = document.getElementById('micStatus');
  const visualizer = document.getElementById('visualizer');

  if (micBtn) micBtn.classList.remove('listening');
  if (micStatus) micStatus.textContent = "Click mic to speak";
  if (visualizer) visualizer.classList.add('hidden');
}

function handleMockResponse(transcript) {
  addChatMessage('user', transcript, null, 'mockMessages');
  
  const currentQ = mockState.questions[mockState.currentIndex];
  mockState.responses[currentQ.id] = transcript;
  mockState.currentIndex++;

  toggleAITyping(true, 'mockTyping');
  
  setTimeout(() => {
    toggleAITyping(false, 'mockTyping');
    
    // Check if it was the "interests" question
    if (currentQ.id === 'interests') {
      const suggestions = getIdeaSuggestions(currentTopic);
      addChatMessage('ai', suggestions, null, 'mockMessages');
      speakText(suggestions.replace(/<[^>]*>/g, '')); // Strip HTML for speech
      
      setTimeout(() => {
        finishMockInterview();
      }, 5000);
    } else if (mockState.currentIndex < mockState.questions.length) {
      askMockQuestion();
    } else {
      finishMockInterview();
    }
  }, 1500);
}

function getIdeaSuggestions(topic) {
  const suggestions = {
    webdev: "That sounds like a brilliant path! In Web Development, you could also explore building **Progressive Web Apps (PWAs)** for offline use, or specialized **AI-driven accessibility tools** that help visually impaired users navigate the web more easily. Both are booming fields!",
    datascience: "What an insightful interest! For Data Science, I'd suggest looking into **Predictive Healthcare Analytics** to improve patient outcomes, or **Real-time Supply Chain Optimization** models. These projects are highly valued by top organizations right now!",
    aiml: "Your vision for AI is inspiring! Beyond that, have you considered **Generative Adversarial Networks (GANs)** for creative arts, or **Federated Learning** to improve privacy in model training? These are cutting-edge areas you'd likely find fascinating!",
    iot: "IoT is full of possibilities! To add to your ideas, think about **Industrial IoT (IIoT)** for predictive maintenance of machinery, or **Smart Grid Management** to optimize city-wide energy consumption. These could really make a massive impact!",
    vlsi: "VLSI is a core technical powerhouse! In this field, you might also be interested in **Low-power SoC (System on Chip) Design** for mobile devices, or **Hardware Accelerators** specifically for deep learning tasks. These are at the heart of modern innovation!",
    embedded: "Embedded systems are everywhere! You could experiment with **Real-Time Operating Systems (RTOS)** for critical safety sensors, or **Wearable Health Monitor** devices. These projects combine hardware and software in really rewarding ways!"
  };
  
  return suggestions[topic] || "That's a fantastic field to be in! You might also want to look into how **Cloud Integration** and **User-Centric Design** are transforming that area. The possibilities for innovation are truly endless, and I'm sure you'll find a way to make your mark!";
}

function finishMockInterview() {
  addChatMessage('ai', "That was an absolutely fantastic session! I'm so impressed with how clearly you expressed yourself. You have a very motivating outlook! Keep practicing, and you'll be unstoppable in any real interview!", null, 'mockMessages');
  speakText("That was an absolutely fantastic session! I'm so impressed with how clearly you expressed yourself. You have a very motivating outlook! Keep practicing, and you'll be unstoppable in any real interview!");
  
  const micContainer = document.querySelector('.mic-btn-container');
  if (micContainer) micContainer.classList.add('hidden');

  const panel = document.getElementById('mockInterviewChat');
  const resultsDiv = document.createElement('div');
  resultsDiv.className = 'results-panel mt-20';
  resultsDiv.innerHTML = `
    <h3>Mock Interview Summary</h3>
    <p class="text-small mb-16">Great job! Here is a summary of what you shared. Use this to refine your pitch!</p>
    <div style="display: flex; flex-direction: column; gap: 12px;">
      ${Object.entries(mockState.responses).map(([key, val]) => `
        <div class="card" style="padding: 12px; border-left: 3px solid var(--primary);">
          <strong style="text-transform: capitalize; font-size: 0.85rem; color: var(--primary);">${key}:</strong>
          <p style="font-size: 0.9rem; margin-top: 4px;">"${val}"</p>
        </div>
      `).join('')}
    </div>
    <button class="btn-secondary btn-sm mt-16" onclick="startMockInterview()">Try Another Session</button>
  `;
  panel.appendChild(resultsDiv);
  resultsDiv.scrollIntoView({ behavior: 'smooth' });
}

function speakText(text) {
  if ('speechSynthesis' in window) {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95; // Slightly slower for friendly/clear tone
    utterance.pitch = 1.0;
    
    // Try to find a nice female voice if available (often sounds more friendly/mentoring)
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Natural') || v.lang.includes('en-GB')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;

    window.speechSynthesis.speak(utterance);
  }
}

// ──── Coding Challenge ────
function updateCodingChallenge() {
  const challenge = assessmentData[currentTopic].coding;
  const subtitle = document.getElementById('codingChallengeSubtitle');
  if (subtitle) subtitle.textContent = challenge.task;
  
  const input = document.getElementById('codeInput');
  if (input) {
    input.value = challenge.starter || '';
    input.placeholder = challenge.task;
  }
  
  const results = document.getElementById('codingResults');
  if (results) results.classList.add('hidden');
}

function checkCode() {
  const input = document.getElementById('codeInput');
  const code = input ? input.value : '';
  const panel = document.getElementById('codingResults');
  if (!panel) return;
  panel.classList.remove('hidden');

  const challenge = assessmentData[currentTopic].coding;
  let score = 0;
  let feedback = [];

  challenge.validation.forEach(v => {
    if (code.includes(v)) {
      score += (100 / challenge.validation.length);
      feedback.push({ icon: 'Status: PASS', text: `Keyword/Pattern "${v}" found.` });
    } else {
      feedback.push({ icon: 'Status: FAIL', text: `Missing logic: ${v}` });
    }
  });

  score = Math.round(score);

  const feedbackHTML = feedback.map(f =>
    `<div class="strength-item"><span class="strength-icon">${f.icon}</span><span>${f.text}</span></div>`
  ).join('');

  const data = getAppData();
  data.codingResults.push({ score, date: new Date().toISOString(), topic: currentTopic });
  saveAppData(data);

  panel.innerHTML = `
    <h3>Code Review</h3>
    <div style="display:flex; gap:16px; margin-bottom:16px; align-items:center;">
      <div class="stat-card" style="min-width:100px;">
        <div class="stat-value" style="color:${score >= 70 ? 'var(--accent)' : 'var(--warning)'};">${score}%</div>
        <div class="stat-label">Score</div>
      </div>
      <div style="flex:1;">${feedbackHTML}</div>
    </div>
    <div style="background:var(--bg); padding:14px; border-radius:8px; font-size:0.85rem; color:var(--text-secondary);">
      <strong>Tip:</strong> ${challenge.hint}
    </div>`;
}

// ──── Aptitude ────
function renderAptitude() {
  const container = document.getElementById('aptitudeContainer');
  if (!container) return;
  container.innerHTML = '';

  const pool = [...aptitudeQuestions];
  shuffleArray(pool);
  const selectedAptitude = pool.slice(0, 5);

  selectedAptitude.forEach((q, idx) => {
    const correctText = q.options[q.correct];
    const shuffledOptions = shuffleArray([...q.options]);
    const newCorrectIdx = shuffledOptions.indexOf(correctText);
    
    q.sessionOptions = shuffledOptions;
    q.sessionCorrect = newCorrectIdx;

    let optionsHTML = '';
    shuffledOptions.forEach((opt, oi) => {
      optionsHTML += `
        <label class="quiz-option" id="apt-${q.id}-${oi}" onclick="selectAptitudeAnswer('${q.id}', ${oi})">
          <input type="radio" name="${q.id}" value="${oi}" />
          <span>${opt}</span>
        </label>`;
    });

    container.innerHTML += `
      <div class="quiz-question" id="question-${q.id}">
        <h4><span class="q-number">Q${idx + 1}.</span> ${q.question}</h4>
        <div class="quiz-options">${optionsHTML}</div>
      </div>`;
  });

  aptitudeAnswers = {};
  const results = document.getElementById('aptitudeResults');
  if (results) results.classList.add('hidden');
}

function selectAptitudeAnswer(qId, optIdx) {
  aptitudeAnswers[qId] = optIdx;
  document.querySelectorAll(`[id^="apt-${qId}"]`).forEach(el => el.classList.remove('selected'));
  const selectedOpt = document.getElementById(`apt-${qId}-${optIdx}`);
  if (selectedOpt) selectedOpt.classList.add('selected');
}

function submitAptitude() {
  const questions = aptitudeQuestions.filter(q => q.sessionOptions);
  let correct = 0;
  const total = questions.length;
  const strengths = [];
  const weaknesses = [];

  questions.forEach(q => {
    const selected = aptitudeAnswers[q.id];
    const allOpts = document.querySelectorAll(`[id^="apt-${q.id}"]`);

    if (selected !== undefined) {
      if (selected === q.sessionCorrect) {
        correct++;
        if (allOpts[selected]) allOpts[selected].classList.add('correct');
        strengths.push('Logical reasoning');
      } else {
        if (allOpts[selected]) allOpts[selected].classList.add('wrong');
        if (allOpts[q.sessionCorrect]) allOpts[q.sessionCorrect].classList.add('correct');
        weaknesses.push('Problem solving');
      }
    } else {
      if (allOpts[q.sessionCorrect]) allOpts[q.sessionCorrect].classList.add('correct');
      weaknesses.push('Problem solving');
    }
  });

  const score = Math.round((correct / total) * 100);

  const data = getAppData();
  data.aptitudeScores.push({ score, date: new Date().toISOString() });
  saveAppData(data);

  const panel = document.getElementById('aptitudeResults');
  if (!panel) return;
  panel.classList.remove('hidden');

  panel.innerHTML = `
    <h3>Aptitude Results</h3>
    <div style="display:flex; gap:20px; margin-bottom:16px; flex-wrap:wrap;">
      <div class="stat-card" style="flex:1; min-width:120px;">
        <div class="stat-value" style="color:${score >= 70 ? 'var(--accent)' : 'var(--warning)'};">${score}%</div>
        <div class="stat-label">Score</div>
      </div>
      <div class="stat-card" style="flex:1; min-width:120px;">
        <div class="stat-value">${correct}/${total}</div>
        <div class="stat-label">Correct</div>
      </div>
    </div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
      <div>
        <h4 style="font-size:0.9rem; font-weight:600; color:var(--accent); margin-bottom:8px;">Strengths</h4>
        <p class="text-small">${strengths.length > 0 ? 'Good at: ' + [...new Set(strengths)].join(', ') : 'Keep practicing!'}</p>
      </div>
      <div>
        <h4 style="font-size:0.9rem; font-weight:600; color:var(--danger); margin-bottom:8px;">Areas to Improve</h4>
        <p class="text-small">${weaknesses.length > 0 ? 'Practice: ' + [...new Set(weaknesses)].join(', ') : 'Great job — no weak areas!'}</p>
      </div>
    </div>
    <button class="btn-secondary btn-sm mt-16" onclick="renderAptitude()">Retake Test</button>`;
}

// ──── Certificate Logic ────
function checkAndAllowCertificate() {
  const data = getAppData();
  const hasQuiz = data.quizScores.some(s => s.topic === currentTopic);
  const hasCoding = data.codingResults.some(s => s.topic === currentTopic);
  const hasAptitude = data.aptitudeScores.length > 0;
  const hasInterview = Object.keys(mockState.responses).length > 0;

  const grid = document.getElementById('certCompletionGrid');
  if (grid) {
    grid.innerHTML = `
      <div class="completion-item ${hasQuiz ? 'done' : 'pending'}">${hasQuiz ? 'Quiz Ready' : 'Quiz Pending'}</div>
      <div class="completion-item ${hasCoding ? 'done' : 'pending'}">${hasCoding ? 'Coding Ready' : 'Coding Pending'}</div>
      <div class="completion-item ${hasAptitude ? 'done' : 'pending'}">${hasAptitude ? 'Aptitude Ready' : 'Aptitude Pending'}</div>
      <div class="completion-item ${hasInterview ? 'done' : 'pending'}">${hasInterview ? 'Interview Ready' : 'Interview Pending'}</div>
    `;
  }

  const btn = document.getElementById('generateCertBtn');
  if (hasQuiz && hasCoding && hasAptitude && hasInterview) {
    btn.disabled = false;
    btn.onclick = generateCertificate;
    btn.textContent = "Generate My Certificate";
  } else {
    btn.disabled = true;
    btn.textContent = "Complete All Modules First";
  }
}

function generateCertificate() {
  const data = getAppData();
  const userName = (data && data.user && data.user.name) ? data.user.name : "Eduspark Student";
  const courseName = capitalizeStr(currentTopic) + " Professional Path";
  const date = new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' });
  
  // Calculate Tier
  const topicQuizScores = (data.quizScores || []).filter(s => s.topic === currentTopic);
  const topicCodingScores = (data.codingResults || []).filter(s => s.topic === currentTopic);
  
  const avgQuiz = topicQuizScores.reduce((acc, s) => acc + s.score, 0) / (topicQuizScores.length || 1);
  const avgCoding = topicCodingScores.reduce((acc, s) => acc + s.score, 0) / (topicCodingScores.length || 1);
  
  const finalScore = (avgQuiz + avgCoding) / 2;
  let tier = "Bronze";
  if (finalScore >= 85) tier = "Gold";
  else if (finalScore >= 65) tier = "Silver";

  const wrapper = document.getElementById('certificateWrapper');
  const status = document.getElementById('certificateStatus');
  const container = document.getElementById('printableCertificate');

  if (status) status.classList.add('hidden');
  if (wrapper) wrapper.classList.remove('hidden');

  if (container) {
    container.innerHTML = `
      <div class="cert-gold-ribbon"></div>
      <div class="cert-gold-ribbon-sub"></div>
      <div class="cert-content">
        <div class="cert-header">
          <div class="cert-logo-placeholder" style="display: flex; align-items: center; gap: 12px;">
            <img src="images/logo.png" alt="EduSpark Logo" style="height: 60px; width: auto;" />
            <span style="font-weight: 800; font-size: 1.4rem; color: #333; letter-spacing: 1px;">EDUSPARK</span>
          </div>
        </div>
        <div class="cert-title">CERTIFICATE</div>
        <div class="cert-subtitle">PROFESSIONAL ACHIEVEMENT</div>
        <p class="cert-present-to">This is to certify that</p>
        <div class="cert-user-name">${userName}</div>
        <p class="cert-body-text">
          has successfully completed the <b>${courseName}</b> requirement and demonstrated 
          mastery through the Eduspark Comprehensive Skill Assessment including Quiz, 
          Coding Challenge, Aptitude, and Mock Interview.
        </p>
        <div class="cert-footer">
          <div class="cert-footer-item" style="width: auto; text-align: left;">
            <div class="cert-footer-label">DATE OF ISSUE</div>
            <div class="cert-footer-value" style="font-weight: 600; color: #333; margin-top: 4px;">${date}</div>
          </div>
          <div class="cert-footer-item" style="width: auto; text-align: right;">
            <div class="cert-footer-label">CERTIFICATE ID</div>
            <div class="cert-footer-value" style="font-weight: 600; color: #333; margin-top: 4px;">EDUS-${Math.random().toString(36).substr(2, 9).toUpperCase()}</div>
          </div>
        </div>
      </div>
      <div class="cert-badge">
        <div class="cert-medal">
          <div class="medal-tier">${tier}</div>
          <div class="medal-stars">★★★</div>
        </div>
        <div class="cert-medal-ribbons">
          <div class="cert-ribbon"></div>
          <div class="cert-ribbon"></div>
        </div>
      </div>
    `;
  }
}

function downloadCertificate() {
  window.print();
}

function shareCertificate() {
  alert("Certificate link copied to clipboard! You can now share it on LinkedIn or with employers.");
}
